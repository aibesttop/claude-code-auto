# 04 - Quality Gates（质量门禁）

> **目的**：定义 AI 交付代码前必须通过的自动化验证标准，确保代码质量、安全性和性能达标

---

## 🎯 质量门禁总览

AI 生成的代码必须通过 **7 个质量门禁** 才算完成任务：

| Gate | 检查内容 | 工具 | 阈值 | 强制性 |
|------|---------|------|------|--------|
| **Gate 1** | 代码质量 | Black, Flake8, Mypy, Pylint | 无错误 | ✅ 强制 |
| **Gate 2** | 测试覆盖 | Pytest + Coverage | ≥ 80% | ✅ 强制 |
| **Gate 3** | 安全扫描 | Bandit, Safety | 无高危 | ✅ 强制 |
| **Gate 4** | 性能基准 | Locust, K6 | P95 < 目标值 | ⚠️ 警告 |
| **Gate 5** | 文档完整性 | 自定义脚本 | 100% | ✅ 强制 |
| **Gate 6** | 部署就绪 | Docker Build | 成功 | ✅ 强制 |
| **Gate 7** | 可观测性 | 日志/指标检查 | 100% | ⚠️ 警告 |

---

## 🔍 Gate 1: 代码质量

### 1.1 代码格式化（Black）

**检查内容**：代码是否符合 PEP 8 风格

```bash
# 检查命令
black --check src/

# 期望输出
All done! ✨ 🍰 ✨
# 如果有问题
would reformat src/main.py
# 则返回非零退出码
```

**配置**：
```toml
# pyproject.toml
[tool.black]
line-length = 100
target-version = ['py311']
```

**修复方法**：
```bash
# AI 应自动运行格式化
black src/
```

---

### 1.2 代码风格检查（Flake8）

**检查内容**：语法错误、未使用的导入、过长的行等

```bash
# 检查命令
flake8 src/ --max-line-length=100 --ignore=E203,W503

# 期望输出
# （无输出表示通过）

# 失败示例
src/main.py:10:1: F401 'os' imported but unused
src/services/auth.py:45:80: E501 line too long (105 > 100 characters)
```

**配置**：
```ini
# .flake8
[flake8]
max-line-length = 100
ignore = E203, W503  # 与 Black 兼容
exclude = .git,__pycache__,migrations,venv
max-complexity = 10
```

**常见错误修复**：
```python
# ❌ F401: 未使用的导入
import os  # 删除或使用

# ❌ E501: 行太长
very_long_function_name(argument1, argument2, argument3, argument4, argument5)

# ✅ 修复：换行
very_long_function_name(
    argument1,
    argument2,
    argument3,
    argument4,
    argument5
)

# ❌ E231: 缺少空格
x=1+2

# ✅ 修复
x = 1 + 2
```

---

### 1.3 类型检查（Mypy）

**检查内容**：类型注解完整性和正确性

```bash
# 检查命令
mypy src/ --strict

# 期望输出
Success: no issues found in 45 source files

# 失败示例
src/services/user.py:23: error: Function is missing a return type annotation
src/models/user.py:15: error: Incompatible return value type (got "None", expected "User")
```

**配置**：
```toml
# pyproject.toml
[tool.mypy]
python_version = "3.11"
strict = true
warn_return_any = true
warn_unused_configs = true
disallow_untyped_defs = true
disallow_incomplete_defs = true
```

**常见错误修复**：
```python
# ❌ 缺少返回类型
def get_user(user_id: str):
    return db.query(User).get(user_id)

# ✅ 修复
from typing import Optional

def get_user(user_id: str) -> Optional[User]:
    return db.query(User).get(user_id)

# ❌ 类型不匹配
def process(items: List[str]) -> int:
    return items  # 返回 List 而非 int

# ✅ 修复
def process(items: List[str]) -> int:
    return len(items)
```

---

### 1.4 代码质量评分（Pylint）

**检查内容**：代码复杂度、命名规范、潜在 bug

```bash
# 检查命令
pylint src/ --fail-under=9.0

# 期望输出
Your code has been rated at 9.5/10

# 失败示例
src/services/auth.py:1:0: C0114: Missing module docstring (missing-module-docstring)
src/utils/crypto.py:45:0: R0913: Too many arguments (6/5) (too-many-arguments)
```

**配置**：
```ini
# .pylintrc
[MASTER]
fail-under=9.0

[MESSAGES CONTROL]
disable=C0111  # 如果不强制 docstring

[DESIGN]
max-args=5
max-locals=15
max-returns=6
max-branches=12
max-statements=50
```

**常见问题修复**：
```python
# ❌ R0913: 参数过多
def create_user(email, password, username, first_name, last_name, age, country):
    pass

# ✅ 修复：使用数据类
from dataclasses import dataclass

@dataclass
class UserCreateData:
    email: str
    password: str
    username: str
    first_name: str
    last_name: str
    age: int
    country: str

def create_user(data: UserCreateData):
    pass

# ❌ C0103: 命名不规范
myList = []  # 应为 snake_case

# ✅ 修复
my_list = []
```

---

## 🧪 Gate 2: 测试覆盖

### 2.1 测试执行

```bash
# 运行所有测试并生成覆盖率报告
pytest tests/ \
    --cov=src \
    --cov-report=html \
    --cov-report=term \
    --cov-fail-under=80 \
    -v

# 期望输出
================== test session starts ==================
collected 156 items

tests/unit/test_validators.py::test_valid_email PASSED    [ 1%]
tests/unit/test_validators.py::test_invalid_email PASSED  [ 2%]
...

---------- coverage: platform linux, python 3.11 ----------
Name                      Stmts   Miss  Cover
---------------------------------------------
src/__init__.py              0      0   100%
src/api/v1/auth.py         120     12    90%
src/services/user.py        85      8    91%
src/utils/validators.py     45      2    96%
---------------------------------------------
TOTAL                      2456    186    92%

================== 156 passed in 12.34s ==================
```

### 2.2 覆盖率要求

| 模块类型 | 最低覆盖率 | 推荐覆盖率 |
|---------|-----------|-----------|
| **业务逻辑（Services）** | 90% | 95% |
| **API 端点** | 80% | 90% |
| **工具函数（Utils）** | 95% | 100% |
| **数据模型（Models）** | 70% | 80% |
| **整体项目** | 80% | 85% |

### 2.3 必须测试的场景

#### 功能测试
- [ ] **正常流程（Happy Path）**：所有功能的标准使用场景
- [ ] **边界条件**：空值、最小值、最大值、边界值
- [ ] **错误处理**：无效输入、资源不存在、权限不足
- [ ] **并发场景**：竞态条件、死锁

#### 安全测试
- [ ] **SQL 注入**：恶意 SQL 语句作为输入
- [ ] **XSS 攻击**：恶意脚本作为输入
- [ ] **认证绕过**：无 Token、过期 Token、伪造 Token
- [ ] **权限提升**：普通用户尝试管理员操作

#### 性能测试
- [ ] **响应时间**：API 端点响应速度
- [ ] **并发负载**：多用户同时访问
- [ ] **数据库性能**：大数据量查询

### 2.4 测试金字塔比例

```
         /\
        /  \
       / E2E \     10% - 端到端测试
      /______\
     /        \
    / Integra- \   20% - 集成测试
   /   tion     \
  /_____________\
 /               \
/  Unit Tests     \ 70% - 单元测试
/__________________\
```

**解释**：
- **单元测试（70%）**：测试单个函数/方法，快速、独立
- **集成测试（20%）**：测试模块间交互，包含数据库
- **E2E 测试（10%）**：测试完整用户流程，模拟真实场景

### 2.5 测试质量检查

```python
# tests/quality_check.py

def check_test_quality():
    """检查测试质量"""
    
    # 1. 检查是否有测试用例
    test_files = glob.glob("tests/**/*.py", recursive=True)
    assert len(test_files) > 0, "No test files found"
    
    # 2. 检查测试命名规范
    for file in test_files:
        assert file.startswith("test_"), f"Invalid test file name: {file}"
    
    # 3. 检查是否有断言
    for file in test_files:
        content = open(file).read()
        assert "assert" in content, f"No assertions found in {file}"
    
    # 4. 检查是否有 docstring
    # ...
    
    print("✅ All test quality checks passed")
```

---

## 🔒 Gate 3: 安全扫描

### 3.1 静态代码安全分析（Bandit）

**检查内容**：常见安全漏洞（SQL 注入、硬编码密钥等）

```bash
# 检查命令
bandit -r src/ -ll -f json -o bandit-report.json

# 期望输出
Run started
# ...
Test results:
    No issues identified.

# 失败示例
>> Issue: [B105:hardcoded_password_string] Possible hardcoded password: 'secret123'
   Severity: Low   Confidence: Medium
   Location: src/config.py:15
```

**配置**：
```yaml
# .bandit
skips: ['B101']  # 跳过 assert 检查（测试代码中常用）
exclude_dirs: ['/tests', '/migrations']
```

**常见问题修复**：
```python
# ❌ B105: 硬编码密码
password = "secret123"

# ✅ 修复：使用环境变量
import os
password = os.getenv("DATABASE_PASSWORD")

# ❌ B608: SQL 注入风险
query = f"SELECT * FROM users WHERE id = {user_id}"

# ✅ 修复：使用参数化查询
query = "SELECT * FROM users WHERE id = ?"
cursor.execute(query, (user_id,))

# ❌ B303: 不安全的哈希函数
import md5
hash = md5.md5(password).hexdigest()

# ✅ 修复：使用 bcrypt
import bcrypt
hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
```

---

### 3.2 依赖漏洞扫描

#### Safety Check

```bash
# 检查命令
safety check --json

# 期望输出
{
  "report": {
    "vulnerabilities": []
  }
}

# 失败示例
+==============================================================================+
| VULNERABILITY REPORT                                                        |
+==============================================================================+
| package: urllib3                                                            |
| installed: 1.26.5                                                           |
| affected: <1.26.9                                                           |
| severity: high                                                              |
+==============================================================================+
```

#### Pip-Audit

```bash
# 检查命令
pip-audit

# 期望输出
No known vulnerabilities found

# 失败示例
Found 2 known vulnerabilities in 2 packages
Name    Version  ID             Fix Versions
------  -------  -------------  ------------
urllib3 1.26.5   PYSEC-2021-108 1.26.9
requests 2.25.0  PYSEC-2022-43  2.27.0
```

**修复方法**：
```bash
# 升级有漏洞的包
pip install --upgrade urllib3 requests

# 更新 requirements.txt
pip freeze > requirements.txt
```

---

### 3.3 秘密泄露扫描（Optional）

```bash
# 使用 gitleaks 扫描
gitleaks detect --source . --verbose

# 期望输出
# （无输出表示未发现秘密）

# 失败示例
Finding:     AWS_SECRET_KEY = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
Secret:      wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
File:        src/config.py
Line:        23
```

---

## ⚡ Gate 4: 性能基准

### 4.1 负载测试（Locust）

```python
# tests/performance/load_test.py

from locust import HttpUser, task, between

class APIUser(HttpUser):
    wait_time = between(1, 3)
    
    def on_start(self):
        """登录获取 Token"""
        response = self.client.post("/api/v1/auth/login", json={
            "email": "test@example.com",
            "password": "SecureP@ss123"
        })
        self.token = response.json()["access_token"]
        self.headers = {"Authorization": f"Bearer {self.token}"}
    
    @task(3)
    def get_user_profile(self):
        """获取用户资料（权重 3）"""
        self.client.get("/api/v1/users/me", headers=self.headers)
    
    @task(1)
    def update_profile(self):
        """更新资料（权重 1）"""
        self.client.patch("/api/v1/users/me", json={
            "username": f"user_{random.randint(1, 1000)}"
        }, headers=self.headers)
```

**运行负载测试**：
```bash
# 1000 用户，50 用户/秒启动速率，运行 5 分钟
locust -f tests/performance/load_test.py \
    --headless \
    --users 1000 \
    --spawn-rate 50 \
    --run-time 5m \
    --host https://api.example.com \
    --html locust-report.html
```

**性能要求**：

| 指标 | 目标 | 警告阈值 | 失败阈值 |
|------|------|---------|---------|
| **P50 响应时间** | < 50ms | < 100ms | > 200ms |
| **P95 响应时间** | < 100ms | < 200ms | > 500ms |
| **P99 响应时间** | < 200ms | < 500ms | > 1000ms |
| **错误率** | < 0.1% | < 1% | > 5% |
| **吞吐量** | > 500 RPS | > 200 RPS | < 100 RPS |

### 4.2 数据库查询性能

```sql
-- 所有查询必须使用 EXPLAIN ANALYZE
EXPLAIN ANALYZE
SELECT u.*, p.* 
FROM users u
LEFT JOIN profiles p ON u.id = p.user_id
WHERE u.email = 'test@example.com';

-- 期望结果
-- ✅ 使用索引扫描（Index Scan）
-- ❌ 全表扫描（Seq Scan）

-- 好的查询计划示例
Index Scan using idx_users_email on users  (cost=0.29..8.31 rows=1)
  Index Cond: (email = 'test@example.com'::text)
  Execution Time: 0.045 ms

-- 坏的查询计划示例
Seq Scan on users  (cost=0.00..10455.00 rows=1)
  Filter: (email = 'test@example.com'::text)
  Execution Time: 125.432 ms
```

**优化建议**：
```sql
-- 创建索引
CREATE INDEX idx_users_email ON users(LOWER(email));

-- 分析表
ANALYZE users;

-- 验证改进
EXPLAIN ANALYZE SELECT * FROM users WHERE LOWER(email) = LOWER('test@example.com');
```

---

## 📚 Gate 5: 文档完整性

### 5.1 API 文档检查

```bash
# 生成 OpenAPI 文档
curl http://localhost:8000/openapi.json > docs/openapi.json

# 检查文档完整性
python scripts/check_api_docs.py
```

```python
# scripts/check_api_docs.py

import json

def check_api_documentation():
    """检查 API 文档完整性"""
    
    with open("docs/openapi.json") as f:
        spec = json.load(f)
    
    issues = []
    
    for path, methods in spec["paths"].items():
        for method, details in methods.items():
            # 检查是否有描述
            if not details.get("description"):
                issues.append(f"{method.upper()} {path}: Missing description")
            
            # 检查是否有响应示例
            if "responses" in details:
                for status, response in details["responses"].items():
                    if "content" in response:
                        content = response["content"].get("application/json", {})
                        if "example" not in content and "examples" not in content:
                            issues.append(
                                f"{method.upper()} {path}: "
                                f"Response {status} missing example"
                            )
            
            # 检查参数是否有说明
            if "parameters" in details:
                for param in details["parameters"]:
                    if not param.get("description"):
                        issues.append(
                            f"{method.upper()} {path}: "
                            f"Parameter '{param['name']}' missing description"
                        )
    
    if issues:
        print("❌ API Documentation Issues:")
        for issue in issues:
            print(f"  - {issue}")
        return False
    else:
        print("✅ API documentation is complete")
        return True
```

### 5.2 代码文档检查

```python
# scripts/check_code_docs.py

import ast
import sys

def check_docstrings(source_dir: str) -> bool:
    """检查公共 API 是否有 docstring"""
    
    missing_docs = []
    
    for filepath in glob.glob(f"{source_dir}/**/*.py", recursive=True):
        if "/tests/" in filepath or "/migrations/" in filepath:
            continue
        
        with open(filepath) as f:
            tree = ast.parse(f.read())
        
        for node in ast.walk(tree):
            # 检查函数/方法
            if isinstance(node, ast.FunctionDef):
                # 跳过私有方法
                if node.name.startswith("_"):
                    continue
                
                # 检查是否有 docstring
                docstring = ast.get_docstring(node)
                if not docstring:
                    missing_docs.append(f"{filepath}:{node.lineno} - {node.name}()")
            
            # 检查类
            elif isinstance(node, ast.ClassDef):
                if not node.name.startswith("_"):
                    docstring = ast.get_docstring(node)
                    if not docstring:
                        missing_docs.append(f"{filepath}:{node.lineno} - class {node.name}")
    
    if missing_docs:
        print("❌ Missing Docstrings:")
        for item in missing_docs:
            print(f"  - {item}")
        return False
    else:
        print("✅ All public APIs have docstrings")
        return True
```

### 5.3 README 完整性

```markdown
# README.md 必须包含：

## ✅ 必需章节
- [ ] 项目简介（一句话说明项目是什么）
- [ ] 功能特性
- [ ] 快速开始（5 分钟能跑起来）
- [ ] 环境变量说明
- [ ] API 使用示例
- [ ] 开发指南
- [ ] 测试运行方法
- [ ] 部署说明
- [ ] 故障排查（常见问题）
- [ ] 贡献指南（如开源）
- [ ] 许可证

## ⚠️ 可选章节
- [ ] 架构图
- [ ] 性能基准
- [ ] 路线图
- [ ] 更新日志
```

---

## 🐳 Gate 6: 部署就绪

### 6.1 Docker 构建

```bash
# 构建镜像
docker build -t myapp:latest .

# 期望输出
Successfully built abc123def456
Successfully tagged myapp:latest

# 检查镜像大小（应 < 500MB）
docker images myapp:latest --format "{{.Size}}"
```

**镜像大小优化**：
```dockerfile
# ❌ 大镜像（1.2GB）
FROM python:3.11
COPY . /app
RUN pip install -r requirements.txt

# ✅ 小镜像（< 300MB）
FROM python:3.11-slim

# 安装系统依赖
RUN apt-get update && apt-get install -y --no-install-recommends \
    gcc \
    && rm -rf /var/lib/apt/lists/*

# 安装 Python 依赖
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# 复制代码
COPY src/ /app/src/

WORKDIR /app

# 使用非 root 用户
RUN useradd -m appuser
USER appuser

CMD ["uvicorn", "src.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

### 6.2 健康检查

```python
# src/api/health.py

from fastapi import APIRouter, status
from sqlalchemy.ext.asyncio import AsyncSession

router = APIRouter()

@router.get("/health", status_code=status.HTTP_200_OK)
async def health_check(db: AsyncSession):
    """
    健康检查端点
    
    检查：
    1. API 服务存活
    2. 数据库连接
    3. Redis 连接
    4. 外部服务连接（可选）
    """
    checks = {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "version": os.getenv("APP_VERSION", "unknown")
    }
    
    # 检查数据库
    try:
        await db.execute("SELECT 1")
        checks["database"] = "ok"
    except Exception as e:
        checks["database"] = "error"
        checks["status"] = "unhealthy"
        logger.error("Database health check failed", error=str(e))
    
    # 检查 Redis
    try:
        await redis.ping()
        checks["redis"] = "ok"
    except Exception as e:
        checks["redis"] = "error"
        checks["status"] = "degraded"  # Redis 故障不影响核心功能
        logger.error("Redis health check failed", error=str(e))
    
    return checks
```

### 6.3 环境变量验证

```python
# scripts/check_env.py

import os
import sys

REQUIRED_VARS = [
    "DATABASE_URL",
    "REDIS_URL",
    "JWT_SECRET_KEY",
    "SENDGRID_API_KEY",
]

OPTIONAL_VARS = [
    "SENTRY_DSN",
    "LOG_LEVEL",
]

def check_environment():
    """检查必需的环境变量"""
    
    missing = []
    for var in REQUIRED_VARS:
        if not os.getenv(var):
            missing.append(var)
    
    if missing:
        print("❌ Missing required environment variables:")
        for var in missing:
            print(f"  - {var}")
        print("\nPlease set these variables in your .env file")
        sys.exit(1)
    
    print("✅ All required environment variables are set")
    
    # 检查可选变量
    missing_optional = [var for var in OPTIONAL_VARS if not os.getenv(var)]
    if missing_optional:
        print("\n⚠️  Optional variables not set:")
        for var in missing_optional:
            print(f"  - {var}")

if __name__ == "__main__":
    check_environment()
```

---

## 📊 Gate 7: 可观测性

### 7.1 日志格式验证

```bash
# 检查日志是否为 JSON 格式
tail -n 100 app.log | jq .

# 期望输出（每行都是有效 JSON）
{
  "timestamp": "2024-11-22T10:30:00Z",
  "level": "INFO",
  "message": "user_login",
  "user_id": "550e8400-e29b-41d4-a716-446655440000",
  "ip_address": "192.168.1.1"
}
```

```python
# scripts/check_logs.py

import json

def validate_log_format(log_file: str) -> bool:
    """验证日志格式"""
    
    required_fields = ["timestamp", "level", "message"]
    
    with open(log_file) as f:
        for i, line in enumerate(f, 1):
            try:
                log_entry = json.loads(line)
                
                # 检查必需字段
                for field in required_fields:
                    if field not in log_entry:
                        print(f"❌ Line {i}: Missing field '{field}'")
                        return False
                
            except json.JSONDecodeError:
                print(f"❌ Line {i}: Invalid JSON")
                return False
    
    print("✅ All log entries are valid JSON with required fields")
    return True
```

### 7.2 指标暴露

```bash
# 检查 /metrics 端点
curl http://localhost:8000/metrics

# 期望输出（Prometheus 格式）
# HELP http_requests_total Total HTTP requests
# TYPE http_requests_total counter
http_requests_total{method="GET",endpoint="/api/v1/users/me",status="200"} 1234

# HELP http_request_duration_seconds HTTP request duration
# TYPE http_request_duration_seconds histogram
http_request_duration_seconds_bucket{le="0.1"} 956
http_request_duration_seconds_bucket{le="0.5"} 1201
```

---

## 🚀 自动化验证脚本

```bash
#!/bin/bash
# scripts/verify_quality.sh - 一键运行所有质量门禁

set -e  # 遇错退出

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo "🔍 Running Quality Gates..."
echo ""

# Gate 1: Code Quality
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Gate 1: Code Quality"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

echo "  📝 Black formatting..."
black --check src/ || { echo -e "${RED}❌ Black check failed${NC}"; exit 1; }
echo -e "${GREEN}  ✅ Black passed${NC}"

echo "  📝 Flake8 linting..."
flake8 src/ || { echo -e "${RED}❌ Flake8 check failed${NC}"; exit 1; }
echo -e "${GREEN}  ✅ Flake8 passed${NC}"

echo "  📝 Mypy type checking..."
mypy src/ --strict || { echo -e "${RED}❌ Mypy check failed${NC}"; exit 1; }
echo -e "${GREEN}  ✅ Mypy passed${NC}"

echo "  📝 Pylint code quality..."
pylint src/ --fail-under=9.0 || { echo -e "${RED}❌ Pylint check failed${NC}"; exit 1; }
echo -e "${GREEN}  ✅ Pylint passed${NC}"

echo ""

# Gate 2: Tests
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Gate 2: Tests & Coverage"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

pytest tests/ \
    --cov=src \
    --cov-report=term \
    --cov-report=html \
    --cov-fail-under=80 \
    -v || { echo -e "${RED}❌ Tests failed${NC}"; exit 1; }
echo -e "${GREEN}  ✅ Tests passed (coverage ≥ 80%)${NC}"

echo ""

# Gate 3: Security
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Gate 3: Security Scan"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

echo "  🔒 Bandit security scan..."
bandit -r src/ -ll || { echo -e "${RED}❌ Bandit found security issues${NC}"; exit 1; }
echo -e "${GREEN}  ✅ Bandit passed${NC}"

echo "  🔒 Safety dependency check..."
safety check || { echo -e "${RED}❌ Vulnerable dependencies found${NC}"; exit 1; }
echo -e "${GREEN}  ✅ Safety passed${NC}"

echo ""

# Gate 4: Performance (optional, warning only)
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Gate 4: Performance (Optional)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# 启动应用
echo "  🚀 Starting application..."
uvicorn src.main:app --host 0.0.0.0 --port 8000 &
APP_PID=$!
sleep 5

# 运行负载测试
echo "  ⚡ Running load test..."
locust -f tests/performance/load_test.py \
    --headless \
    --users 100 \
    --spawn-rate 10 \
    --run-time 60s \
    --host http://localhost:8000 || {
        echo -e "${YELLOW}⚠️  Performance test failed (warning only)${NC}"
    }

kill $APP_PID
echo -e "${GREEN}  ✅ Performance test completed${NC}"

echo ""

# Gate 5: Documentation
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Gate 5: Documentation"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

python scripts/check_code_docs.py || { echo -e "${RED}❌ Documentation incomplete${NC}"; exit 1; }
echo -e "${GREEN}  ✅ Documentation complete${NC}"

echo ""

# Gate 6: Build
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Gate 6: Docker Build"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

docker build -t myapp:test . || { echo -e "${RED}❌ Docker build failed${NC}"; exit 1; }

# 检查镜像大小
IMAGE_SIZE=$(docker images myapp:test --format "{{.Size}}")
echo "  📦 Image size: $IMAGE_SIZE"
echo -e "${GREEN}  ✅ Docker build succeeded${NC}"

echo ""

# Gate 7: Observability
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Gate 7: Observability"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

python scripts/check_logs.py app.log || {
    echo -e "${YELLOW}⚠️  Log format issues (warning only)${NC}"
}
echo -e "${GREEN}  ✅ Observability checks passed${NC}"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "${GREEN}✅ All quality gates passed!${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
```

---

## 📝 质量报告

运行完所有门禁后，生成质量报告：

```python
# scripts/generate_quality_report.py

import json
from datetime import datetime

def generate_report():
    """生成质量报告"""
    
    report = {
        "timestamp": datetime.utcnow().isoformat(),
        "version": os.getenv("APP_VERSION", "unknown"),
        "gates": {
            "code_quality": {
                "status": "passed",
                "checks": {
                    "black": "passed",
                    "flake8": "passed",
                    "mypy": "passed",
                    "pylint": "9.5/10"
                }
            },
            "tests": {
                "status": "passed",
                "total": 156,
                "passed": 156,
                "failed": 0,
                "coverage": "92%"
            },
            "security": {
                "status": "passed",
                "vulnerabilities": 0
            },
            "performance": {
                "status": "warning",
                "p95_latency": "185ms",
                "target": "200ms"
            }
        }
    }
    
    with open("quality-report.json", "w") as f:
        json.dump(report, f, indent=2)
    
    print("📊 Quality report generated: quality-report.json")
```

---

## 📝 变更日志

| 日期 | 版本 | 变更内容 |
|------|------|---------|
| 2024-11-22 | v1.0.0 | 初始质量门禁定义 |
