# 05 - AI Prompt Template（AI 任务提示词模板）

> **目的**：提供标准化的 AI 任务提示词模板，确保 AI 能够准确理解任务并交付高质量代码

---

## 📋 通用任务模板

### 基础模板结构

```markdown
# Task: [任务名称]

## Context Documents
Please read the following documents in order to understand the project context:

1. `/docs/00-project-context.md` - Project vision, constraints, and preferences
2. `/docs/01-requirements.md#[REQUIREMENT_ID]` - Detailed functional requirements
3. `/docs/02-architecture.md` - System architecture and design patterns
4. `/docs/03-implementation-guide.md` - Coding standards and best practices
5. `/docs/04-quality-gates.md` - Quality assurance requirements

## Task Description
[详细的任务描述]

## Specific Requirements
[从需求文档引用的具体需求 ID，如 FR-001]

## Deliverables
1. **Source Code**
   - [具体文件清单]
   - Follow directory structure in `02-architecture.md`
   - Adhere to coding standards in `03-implementation-guide.md`
   - Include complete type hints and docstrings

2. **Tests**
   - Implement all test cases from `01-requirements.md#[REQUIREMENT_ID]`
   - Achieve minimum 80% code coverage
   - Include: unit tests, integration tests, security tests

3. **Documentation**
   - Update API documentation (OpenAPI/Swagger)
   - Add inline comments for complex logic
   - Create/update database migration scripts if needed

4. **Quality Assurance**
   - Pass all quality gates defined in `04-quality-gates.md`
   - Run `scripts/verify_quality.sh` and ensure all checks pass
   - Fix all linting and security issues

## Success Criteria
- [ ] All tests pass (`pytest tests/`)
- [ ] Code coverage ≥ 80%
- [ ] No linting errors (`black`, `flake8`, `mypy`, `pylint ≥ 9.0`)
- [ ] No security vulnerabilities (`bandit`, `safety`)
- [ ] Performance requirements met (if applicable)
- [ ] Docker image builds successfully
- [ ] Health check endpoint returns 200

## Constraints
- Do NOT ask for clarification - all information is in the documentation
- Do NOT use deprecated libraries or patterns
- Do NOT hardcode secrets (use environment variables)
- Do NOT skip writing tests
- Do NOT deviate from the defined architecture

## Validation Steps
After implementation, execute:
```bash
bash scripts/verify_quality.sh
```

If all quality gates pass, the task is complete.
```

---

## 🎯 具体任务模板示例

### 示例 1: 实现单个 API 端点

```markdown
# Task: Implement User Registration Endpoint

## Context Documents
1. `/docs/00-project-context.md` - Understand project constraints
2. `/docs/01-requirements.md#FR-001` - User registration specification
3. `/docs/02-architecture.md` - API design and database schema
4. `/docs/03-implementation-guide.md` - Error handling patterns
5. `/docs/04-quality-gates.md` - Quality requirements

## Task Description
Implement the user registration endpoint (`POST /api/v1/auth/register`) according to the specifications in `01-requirements.md#FR-001`.

## Specific Requirements
Reference: `01-requirements.md#FR-001`

Key points:
- Accept email, password, and username
- Validate all inputs (see YAML spec in FR-001)
- Hash password with bcrypt (cost=12)
- Store user in PostgreSQL
- Send verification email asynchronously
- Return 201 with user details (excluding password)
- Handle all error cases (duplicate email, weak password, rate limiting)

## Deliverables

### 1. Source Code Files
- `src/api/v1/auth.py` - API endpoint implementation
- `src/services/auth_service.py` - Business logic
- `src/repositories/user_repository.py` - Database operations
- `src/schemas/auth.py` - Pydantic request/response models
- `src/tasks/email.py` - Async email sending task
- `migrations/versions/001_create_users_table.py` - Database migration

### 2. Test Files
- `tests/unit/test_auth_validators.py` - Input validation tests
- `tests/integration/test_auth_register.py` - All test cases from FR-001
- `tests/integration/test_auth_rate_limiting.py` - Rate limit tests

### 3. Documentation Updates
- Update `docs/openapi.json` (or ensure FastAPI auto-generates correctly)
- Add docstrings to all public functions

## Success Criteria
- [ ] Endpoint responds with correct status codes for all scenarios
- [ ] All test cases from FR-001 pass
- [ ] Password is hashed (never stored in plain text)
- [ ] Email verification is sent asynchronously (doesn't block response)
- [ ] Rate limiting works correctly (3 attempts per 5 minutes)
- [ ] Duplicate email detection works (case-insensitive)
- [ ] Code coverage ≥ 90% for auth module
- [ ] All quality gates pass

## Implementation Hints
1. Start with database migration to create `users` table
2. Implement repository layer for database operations
3. Implement service layer for business logic
4. Implement API endpoint (thin layer, delegates to service)
5. Implement all test cases from FR-001
6. Run quality gates and fix issues

## Constraints
- Use SQLAlchemy async ORM (not raw SQL)
- Use Pydantic for input validation
- Use Celery for async email tasks
- Follow error handling pattern from `03-implementation-guide.md#3`
- NO plain text passwords anywhere (logs, responses, database)

## Validation
```bash
# Run these commands to verify:
pytest tests/integration/test_auth_register.py -v
pytest tests/unit/test_auth_validators.py -v
bash scripts/verify_quality.sh
```
```

---

### 示例 2: 实现完整功能模块

```markdown
# Task: Implement Complete Authentication Module

## Context Documents
1. `/docs/00-project-context.md`
2. `/docs/01-requirements.md#FR-001,FR-002` - Registration & Login specs
3. `/docs/02-architecture.md#5` - Security architecture
4. `/docs/03-implementation-guide.md`
5. `/docs/04-quality-gates.md`

## Task Description
Implement a complete authentication module including:
- User registration (FR-001)
- User login (FR-002)
- Token refresh
- Logout (token revocation)
- JWT token generation and validation

## Deliverables

### 1. API Endpoints
- `POST /api/v1/auth/register` - User registration
- `POST /api/v1/auth/login` - User login
- `POST /api/v1/auth/refresh` - Refresh access token
- `POST /api/v1/auth/logout` - Logout (revoke refresh token)

### 2. Source Code Structure
```
src/
├── api/v1/auth.py              # API endpoints
├── services/
│   ├── auth_service.py         # Core auth logic
│   └── token_service.py        # JWT operations
├── repositories/
│   ├── user_repository.py      # User DB operations
│   └── session_repository.py   # Session management
├── schemas/
│   └── auth.py                 # Request/response models
├── core/
│   ├── security.py             # JWT, password hashing
│   └── exceptions.py           # Custom exceptions
└── tasks/
    └── email.py                # Async email tasks
```

### 3. Database Tables
- `users` - User accounts
- `sessions` - Active refresh tokens

### 4. Tests
- Unit tests for all services (>90% coverage)
- Integration tests for all endpoints
- Security tests (SQL injection, invalid tokens, etc.)
- Performance tests (response time < 200ms P95)

## Success Criteria
- [ ] All 4 endpoints implemented and working
- [ ] JWT tokens (Access: 15min, Refresh: 7d)
- [ ] Tokens can be revoked (logout works)
- [ ] Failed login attempts are rate-limited
- [ ] Password security (bcrypt, no plain text)
- [ ] All FR-001 and FR-002 test cases pass
- [ ] Code coverage ≥ 85% for auth module
- [ ] All quality gates pass
- [ ] Security scan passes (no vulnerabilities)

## Implementation Order
1. Database migrations (users, sessions tables)
2. Core security utilities (JWT, password hashing)
3. Repository layer (database operations)
4. Service layer (business logic)
5. API endpoints (thin routing layer)
6. Background tasks (email sending)
7. Comprehensive tests
8. Quality gates validation

## Constraints
- Use RS256 for JWT (asymmetric encryption)
- Store refresh tokens in Redis (for revocation)
- Use bcrypt with cost factor 12 for passwords
- Implement rate limiting (Redis-based)
- All async operations (FastAPI + asyncpg)

## Validation
```bash
# Test individual components
pytest tests/unit/services/test_auth_service.py -v
pytest tests/integration/test_auth_*.py -v

# Run full quality gates
bash scripts/verify_quality.sh

# Manual API testing
curl -X POST http://localhost:8000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"SecureP@ss123","username":"testuser"}'
```
```

---

### 示例 3: 数据库迁移任务

```markdown
# Task: Create Database Migration for Users Table

## Context Documents
1. `/docs/02-architecture.md#3.2` - Users table schema
2. `/docs/03-implementation-guide.md` - Migration best practices

## Task Description
Create an Alembic migration script to create the `users` table with all required fields, constraints, and indexes.

## Specific Requirements

### Table Schema (from 02-architecture.md)
```sql
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) NOT NULL,
    email_verified BOOLEAN NOT NULL DEFAULT FALSE,
    username VARCHAR(20) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    last_login_at TIMESTAMP,
    deleted_at TIMESTAMP
);
```

### Constraints
- Unique constraint on LOWER(email)
- Unique constraint on LOWER(username)

### Indexes
- Index on LOWER(email)
- Index on LOWER(username)
- Index on created_at DESC
- Index on deleted_at WHERE deleted_at IS NULL

### Triggers
- Auto-update `updated_at` on row modification

## Deliverables

### Migration File
`migrations/versions/001_create_users_table.py`

Must include:
- `upgrade()` function with table creation
- `downgrade()` function with rollback logic
- All constraints and indexes
- Trigger for auto-updating `updated_at`

## Success Criteria
- [ ] Migration runs successfully: `alembic upgrade head`
- [ ] Rollback works: `alembic downgrade -1`
- [ ] All indexes are created
- [ ] Unique constraints work (duplicate email/username rejected)
- [ ] Trigger updates `updated_at` on UPDATE
- [ ] No SQL errors in logs

## Implementation Template
```python
"""create users table

Revision ID: 001
Revises: 
Create Date: 2024-11-22

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = '001'
down_revision = None

def upgrade():
    # TODO: Implement table creation
    # - Create table with all columns
    # - Add unique constraints
    # - Create indexes
    # - Create trigger function and trigger
    pass

def downgrade():
    # TODO: Implement rollback
    # - Drop table
    pass
```

## Validation
```bash
# Test migration
alembic upgrade head
alembic current  # Should show 001

# Test rollback
alembic downgrade -1
alembic current  # Should show (none)

# Re-apply
alembic upgrade head

# Verify in database
psql -U user -d mydb -c "\d users"
```
```

---

### 示例 4: Bug 修复任务

```markdown
# Task: Fix Password Reset Token Expiration Bug

## Issue Description
Password reset tokens are not expiring after 1 hour as specified. Tokens remain valid indefinitely, creating a security risk.

**Bug Report**: #123  
**Severity**: High (Security)  
**Affected Module**: `src/services/auth_service.py`

## Root Cause Analysis Needed
Investigate:
1. Where are reset tokens generated?
2. How is expiration time set?
3. Where is expiration validated?
4. Why is validation not working?

## Expected Behavior
- Reset tokens should expire after 1 hour (3600 seconds)
- Expired tokens should be rejected with 400 error
- Error message: "Token has expired. Please request a new password reset."

## Deliverables

### 1. Bug Fix
- Identify root cause
- Fix the issue in appropriate file(s)
- Add validation for token expiration

### 2. Tests
- Add test case: `test_password_reset_token_expires_after_one_hour()`
- Add test case: `test_expired_token_rejected()`
- Ensure existing tests still pass

### 3. Documentation
- Update docstring if behavior changes
- Add inline comment explaining the fix

## Success Criteria
- [ ] Tokens expire after exactly 1 hour
- [ ] Expired tokens return 400 error
- [ ] New test cases pass
- [ ] All existing tests still pass
- [ ] No regression in other features
- [ ] Code quality gates pass

## Investigation Steps
1. Read `src/services/auth_service.py` - password reset logic
2. Check `src/core/security.py` - token generation
3. Review `src/api/v1/auth.py` - token validation endpoint
4. Check if `exp` claim is set correctly in JWT
5. Verify token validation logic

## Testing Strategy
```python
# Suggested test case
def test_password_reset_token_expires():
    # Generate token
    token = generate_reset_token(user.id)
    
    # Mock time to 1 hour + 1 second later
    with freezegun.freeze_time(
        datetime.now() + timedelta(hours=1, seconds=1)
    ):
        # Attempt to use token
        response = client.post("/api/v1/auth/reset-password", json={
            "token": token,
            "new_password": "NewSecure123!"
        })
        
        # Should reject expired token
        assert response.status_code == 400
        assert response.json()["error"] == "TOKEN_EXPIRED"
```

## Constraints
- Do NOT change token format (must remain JWT)
- Do NOT break existing password reset flow
- Do NOT skip writing tests for the fix

## Validation
```bash
# Run affected tests
pytest tests/integration/test_auth_password_reset.py -v

# Run full test suite
pytest tests/

# Verify no security regressions
bandit -r src/
```
```

---

## 🎨 高级提示词技巧

### 技巧 1: 分层次提供信息

```markdown
# Task: [任务名称]

## High-Level Goal
[一句话说明要做什么]

## Why This Matters
[为什么这个功能重要，业务价值]

## Technical Details
[技术实现细节]

## Edge Cases to Consider
[需要特别注意的边界情况]
```

### 技巧 2: 使用示例驱动

```markdown
## Examples

### Good Example ✅
```python
# 这样写是正确的
def get_user(user_id: str) -> Optional[User]:
    return db.query(User).filter(User.id == user_id).first()
```

### Bad Example ❌
```python
# 不要这样写
def getUser(id):  # 缺少类型注解，命名不规范
    return db.query(User).get(id)
```
```

### 技巧 3: 明确"不要做什么"

```markdown
## Anti-Patterns to Avoid

❌ **Do NOT** use raw SQL strings (SQL injection risk)
❌ **Do NOT** store passwords in plain text
❌ **Do NOT** skip input validation
❌ **Do NOT** hardcode API keys
❌ **Do NOT** use `except: pass` (swallow errors)
```

### 技巧 4: 提供决策树

```markdown
## Decision Flow

```mermaid
graph TD
    A[Receive Request] --> B{Email exists?}
    B -->|Yes| C[Return 409 Conflict]
    B -->|No| D{Password valid?}
    D -->|No| E[Return 400 Bad Request]
    D -->|Yes| F[Hash Password]
    F --> G[Create User]
    G --> H[Send Verification Email]
    H --> I[Return 201 Created]
```
```

### 技巧 5: 分阶段实施

```markdown
## Implementation Phases

### Phase 1: Core Functionality (Required)
- [ ] Database schema
- [ ] Basic CRUD operations
- [ ] Input validation

### Phase 2: Security (Required)
- [ ] Authentication
- [ ] Authorization
- [ ] Rate limiting

### Phase 3: Optimization (Optional)
- [ ] Caching
- [ ] Performance tuning
- [ ] Monitoring

**Note**: Complete Phase 1 and 2 before moving to Phase 3.
```

---

## 🔄 迭代改进模板

当 AI 第一次实现不满足要求时，使用此模板：

```markdown
# Task: Improve [Feature Name] - Iteration 2

## Previous Implementation Issues
1. ❌ Issue 1: [描述问题]
   - **Why it's wrong**: [解释]
   - **How to fix**: [具体修改建议]

2. ❌ Issue 2: [描述问题]
   - **Why it's wrong**: [解释]
   - **How to fix**: [具体修改建议]

## Keep These Parts
✅ **Good**: Database schema design  
✅ **Good**: Input validation logic  
✅ **Good**: Error handling structure

## Change These Parts
🔄 **Needs improvement**: Token expiration logic  
🔄 **Needs improvement**: Test coverage (currently 65%, need 80%+)

## Specific Changes Required
1. In `src/services/auth_service.py`, line 45:
   ```python
   # ❌ Current (wrong)
   token = jwt.encode({"user_id": user.id}, SECRET_KEY)
   
   # ✅ Change to (correct)
   token = jwt.encode(
       {"user_id": user.id, "exp": datetime.utcnow() + timedelta(hours=1)},
       SECRET_KEY,
       algorithm="RS256"
   )
   ```

2. Add missing test case:
   ```python
   def test_token_expires_after_one_hour():
       # TODO: Implement this test
       pass
   ```

## Validation
After making changes, run:
```bash
pytest tests/integration/test_auth.py::test_token_expires_after_one_hour -v
bash scripts/verify_quality.sh
```

All quality gates must pass before considering this iteration complete.
```

---

## 📋 任务清单模板

```markdown
# Task Checklist: [Feature Name]

## Pre-Implementation
- [ ] Read all context documents
- [ ] Understand requirements fully
- [ ] Identify dependencies
- [ ] Plan implementation approach

## Implementation
- [ ] Write database migration (if needed)
- [ ] Implement data models
- [ ] Implement repository layer
- [ ] Implement service layer
- [ ] Implement API endpoints
- [ ] Add input validation
- [ ] Add error handling
- [ ] Add logging

## Testing
- [ ] Write unit tests (≥90% coverage)
- [ ] Write integration tests
- [ ] Write security tests
- [ ] All tests pass

## Quality Gates
- [ ] `black --check src/` passes
- [ ] `flake8 src/` passes
- [ ] `mypy src/ --strict` passes
- [ ] `pylint src/ --fail-under=9.0` passes
- [ ] `pytest --cov-fail-under=80` passes
- [ ] `bandit -r src/` passes
- [ ] `safety check` passes

## Documentation
- [ ] Add docstrings to all public functions
- [ ] Update API documentation
- [ ] Add inline comments for complex logic
- [ ] Update README if needed

## Final Verification
- [ ] Docker build succeeds
- [ ] Health check endpoint works
- [ ] Manual testing completed
- [ ] All deliverables provided

## Submission
When all items are checked, the task is complete and ready for review.
```

---

## 🎓 提示词编写最佳实践

### DO ✅

1. **Be Specific**
   ```markdown
   ✅ Good: "Implement JWT authentication with RS256 algorithm, 15-minute access tokens"
   ❌ Vague: "Add authentication"
   ```

2. **Provide Context**
   ```markdown
   ✅ Good: "This endpoint will be called by mobile apps with high traffic (1000 RPS)"
   ❌ Lacking: "Create an API endpoint"
   ```

3. **Link to Documentation**
   ```markdown
   ✅ Good: "Follow the error handling pattern in `03-implementation-guide.md#3.1`"
   ❌ Vague: "Handle errors properly"
   ```

4. **Include Examples**
   ```markdown
   ✅ Good: Show both correct and incorrect code examples
   ❌ Abstract: "Write good code"
   ```

5. **Define Success Explicitly**
   ```markdown
   ✅ Good: Checkable list of acceptance criteria
   ❌ Vague: "Make it work"
   ```

### DON'T ❌

1. **Don't Be Ambiguous**
   ```markdown
   ❌ Bad: "Make it faster"
   ✅ Good: "Reduce P95 latency from 500ms to <200ms"
   ```

2. **Don't Assume Knowledge**
   ```markdown
   ❌ Bad: "Use the standard pattern"
   ✅ Good: "Use the Repository pattern defined in `02-architecture.md#4`"
   ```

3. **Don't Skip Validation**
   ```markdown
   ❌ Bad: "Implement and we'll test later"
   ✅ Good: "Run `bash scripts/verify_quality.sh` after implementation"
   ```

4. **Don't Overload**
   ```markdown
   ❌ Bad: "Implement auth, API, tests, docs, and deployment in one task"
   ✅ Good: Break into smaller, focused tasks
   ```

---

## 📝 变更日志

| 日期 | 版本 | 变更内容 |
|------|------|---------|
| 2024-11-22 | v1.0.0 | 初始 AI 提示词模板 |
