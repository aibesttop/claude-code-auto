# 00 - Project Context（项目上下文）

> **目的**：让 AI 理解项目的"灵魂" —— 为什么做、为谁做、在什么约束下做

---

## 1. 项目愿景（Vision）

### 1.1 一句话描述
<!-- 用一句话说清楚项目是什么 -->
**示例**：构建一个智能代码审查工具，自动检测代码质量问题，为开发团队提供实时反馈。

### 1.2 问题陈述（Problem Statement）

**当前痛点**：
- 问题 1：手动代码审查耗时长，平均每个 PR 需要 2 小时
- 问题 2：审查标准不统一，不同审查者给出不同意见
- 问题 3：新人代码质量参差不齐，影响项目稳定性

**为什么现有方案不够好**：
- 传统 Linter（如 ESLint）：只能检查语法，无法理解业务逻辑
- SonarQube：规则过于死板，误报率高
- 人工审查：速度慢，成本高，无法覆盖所有代码

**我们的独特价值**：
- 使用 LLM 理解代码语义，提供上下文相关的建议
- 学习团队的代码风格，提供个性化反馈
- 实时反馈，开发者提交即可看到结果

### 1.3 目标用户（Target Users）

| 用户角色 | 痛点 | 期望 |
|---------|------|------|
| **初级开发者** | 不知道代码哪里写得不好 | 得到清晰的改进建议 |
| **资深开发者** | 审查代码占用大量时间 | 自动化常规审查，专注架构 |
| **技术经理** | 难以衡量代码质量趋势 | 可视化质量报告 |

**典型使用场景**：
1. 开发者提交 Pull Request → 系统自动审查 → 30 秒内返回建议
2. 团队每周查看代码质量仪表板 → 识别问题模块 → 安排重构
3. 新人入职 → 系统根据历史代码学习团队风格 → 指导新人写出符合规范的代码

---

## 2. 核心约束（Constraints）

### 2.1 技术栈限定

**后端**：
- 语言：Python 3.11+
- 框架：FastAPI 0.104+
- 数据库：PostgreSQL 15 + Redis 7
- 消息队列：RabbitMQ 3.12
- LLM：Anthropic Claude 3.5 Sonnet

**前端**：
- 框架：Next.js 14 (App Router)
- 语言：TypeScript 5.0+
- UI 库：shadcn/ui + Tailwind CSS
- 状态管理：Zustand

**基础设施**：
- 容器：Docker + Docker Compose
- 部署：Vercel (Frontend) + Railway (Backend)
- CI/CD：GitHub Actions
- 监控：Sentry + Grafana

**禁止使用**：
- ❌ Flask（性能不足）
- ❌ MongoDB（需要事务支持）
- ❌ Class Components（使用 Hooks）

### 2.2 性能要求

| 指标 | 目标 | 测量方法 |
|------|------|---------|
| **API 响应时间** | P50 < 100ms, P95 < 200ms | Locust 负载测试 |
| **代码审查延迟** | < 30 秒（小于 500 行代码） | 实际测试 |
| **并发用户** | 支持 1000 并发请求 | K6 压测 |
| **数据库查询** | 所有查询 < 50ms | EXPLAIN ANALYZE |
| **前端首屏加载** | < 2 秒 | Lighthouse |

### 2.3 安全要求

**合规性**：
- ✅ GDPR 合规（用户数据可删除）
- ✅ SOC 2 Type II（数据加密存储）
- ✅ OWASP Top 10 防护

**安全措施**：
- 传输加密：TLS 1.3
- 存储加密：AES-256（敏感数据）
- 认证：JWT（Access Token 15min + Refresh Token 7天）
- 授权：RBAC（Role-Based Access Control）
- 日志脱敏：自动移除密码、Token、API Key
- Rate Limiting：每用户 100 req/min

### 2.4 预算约束

**月度预算**：$500

**成本分配**：
- LLM API：$300（优先使用 Claude，超预算降级到 GPT-3.5）
- 基础设施：$100（Vercel Pro + Railway Hobby）
- 监控与日志：$50（Sentry 免费层 + Grafana Cloud）
- 其他服务：$50（SendGrid, Stripe）

**成本优化策略**：
- 使用 Prompt Caching 减少 LLM 调用
- 静态资产使用 CDN（Cloudflare 免费层）
- 数据库连接池复用
- 后台任务批量处理

### 2.5 时间约束

| 里程碑 | 时间 | 交付物 |
|--------|------|--------|
| **MVP** | 2 周 | 基础代码审查功能 |
| **Beta** | 4 周 | 用户管理 + 团队协作 |
| **v1.0** | 8 周 | 完整功能 + 文档 |

---

## 3. 不做什么（Non-Goals）

明确在当前版本**不**实现的功能，避免范围蔓延：

- ❌ **不支持实时协作**（v1.0 阶段）：类似 Google Docs 的多人同时编辑
  - *理由*：技术复杂度高，优先级低
  
- ❌ **不做移动端原生 APP**：仅提供响应式 Web（PWA）
  - *理由*：预算和时间有限
  
- ❌ **不集成支付系统**：使用 Stripe Checkout（第三方）
  - *理由*：PCI DSS 合规成本高
  
- ❌ **不支持私有化部署**（v1.0）：仅 SaaS 模式
  - *理由*：维护成本高，v2.0 考虑
  
- ❌ **不支持超过 10 种编程语言**（MVP）：先支持 Python, JavaScript, TypeScript
  - *理由*：聚焦核心用户群

---

## 4. 技术偏好与代码风格（Coding Preferences）

### 4.1 代码风格

**Python**：
- 格式化：Black（行宽 100）
- Linting：Flake8 + Pylint
- 类型检查：Mypy（strict 模式）
- 导入排序：isort

**TypeScript**：
- 格式化：Prettier
- Linting：ESLint（airbnb-typescript）
- 类型：strict mode

**命名规范**：
```python
# 变量和函数：snake_case
user_email = "test@example.com"
def calculate_total_price():
    pass

# 类：PascalCase
class UserService:
    pass

# 常量：UPPER_SNAKE_CASE
MAX_RETRY_COUNT = 3

# 私有成员：前缀 _
class MyClass:
    def _internal_method(self):
        pass
```

### 4.2 错误处理偏好

**优先使用**：
```python
# ✅ 返回 Result 类型（显式错误处理）
from typing import Union
from dataclasses import dataclass

@dataclass
class Success:
    value: Any

@dataclass
class Failure:
    error: str

Result = Union[Success, Failure]

def divide(a: int, b: int) -> Result:
    if b == 0:
        return Failure(error="Division by zero")
    return Success(value=a / b)
```

**避免使用**：
```python
# ❌ 用异常控制业务流程
def get_user(user_id: str):
    user = db.query(User).get(user_id)
    if not user:
        raise UserNotFoundError()  # 避免用异常表示"未找到"
    return user
```

### 4.3 日志级别

| 环境 | 级别 | 输出格式 |
|------|------|---------|
| **开发（Development）** | DEBUG | 带颜色的文本 |
| **测试（Staging）** | INFO | JSON（结构化） |
| **生产（Production）** | WARNING | JSON + 发送到 Sentry |

**日志示例**：
```python
# ✅ 结构化日志
logger.info(
    "user_login_success",
    user_id=user.id,
    ip_address=request.client.host,
    user_agent=request.headers.get("User-Agent")
)

# ❌ 字符串拼接
logger.info(f"User {user.id} logged in from {ip}")
```

### 4.4 注释要求

**必须写注释**：
- ✅ 公共 API（函数、类、模块）
- ✅ 复杂算法（O(n²) 以上）
- ✅ 非显而易见的业务逻辑
- ✅ 临时解决方案（标注 TODO 或 FIXME）

**不需要注释**：
- ❌ 显而易见的代码（如 `user_name = user.name`）
- ❌ 重复函数签名的信息

**Docstring 格式**（Google Style）：
```python
def calculate_discount(
    price: Decimal,
    discount_rate: float,
    user_tier: str
) -> Decimal:
    """
    计算折扣后的价格
    
    Args:
        price: 原价（必须 > 0）
        discount_rate: 折扣率（0.0 ~ 1.0）
        user_tier: 用户等级（"basic" | "premium" | "enterprise"）
        
    Returns:
        折扣后的价格（保留 2 位小数）
        
    Raises:
        ValueError: 如果 price <= 0 或 discount_rate 不在有效范围
        
    Example:
        >>> calculate_discount(Decimal("100.00"), 0.2, "premium")
        Decimal('80.00')
    """
    if price <= 0:
        raise ValueError("Price must be positive")
    if not 0 <= discount_rate <= 1:
        raise ValueError("Discount rate must be between 0 and 1")
    
    # Premium 用户额外 5% 折扣
    if user_tier == "premium":
        discount_rate += 0.05
    
    return (price * (1 - discount_rate)).quantize(Decimal("0.01"))
```

### 4.5 测试风格

**测试命名**：
```python
# ✅ 描述性命名
def test_user_registration_with_valid_email_succeeds():
    pass

def test_user_registration_with_duplicate_email_returns_409():
    pass

# ❌ 模糊命名
def test_register():
    pass
```

**测试结构**（AAA 模式）：
```python
def test_create_invoice():
    # Arrange（准备）
    user = UserFactory.create()
    items = [ItemFactory.create() for _ in range(3)]
    
    # Act（执行）
    invoice = create_invoice(user, items)
    
    # Assert（断言）
    assert invoice.total > 0
    assert len(invoice.items) == 3
    assert invoice.status == InvoiceStatus.DRAFT
```

---

## 5. 已有资产（Existing Assets）

列出可复用的资源，避免 AI 重复造轮子：

### 5.1 代码库

| 仓库 | 地址 | 用途 |
|------|------|------|
| **Backend** | https://github.com/company/backend | 现有 API 服务 |
| **Frontend** | https://github.com/company/frontend | 现有前端应用 |
| **共享库** | https://github.com/company/common-lib | 工具函数、类型定义 |

### 5.2 API 文档

- Swagger UI: https://api.example.com/docs
- Postman Collection: [链接]

### 5.3 设计资源

- **设计系统**：使用 shadcn/ui（无需自定义组件）
- **Figma 文件**：https://figma.com/file/xxx
- **品牌指南**：`/docs/brand-guidelines.pdf`

### 5.4 基础设施

| 服务 | 提供商 | 用途 |
|------|--------|------|
| **前端托管** | Vercel | 自动部署 + CDN |
| **后端托管** | Railway | Docker 容器 |
| **数据库** | Supabase | PostgreSQL 托管 |
| **缓存** | Upstash Redis | Serverless Redis |
| **文件存储** | Cloudflare R2 | S3 兼容存储 |
| **邮件** | SendGrid | 事务性邮件 |

### 5.5 开发工具

- **IDE**：VS Code（推荐插件：Pylance, ESLint, Prettier）
- **API 测试**：Postman + HTTPie
- **数据库工具**：DBeaver（PostgreSQL GUI）
- **协作**：Slack（通知集成）、Linear（任务管理）

---

## 6. 团队与协作（Team Context）

### 6.1 团队组成

| 角色 | 人数 | 职责 |
|------|------|------|
| **全栈开发** | 2 | 功能实现 |
| **DevOps** | 1（兼职）| CI/CD、监控 |
| **产品经理** | 1 | 需求定义、优先级 |

### 6.2 工作流程

1. **需求评审**：每周一，PM 讲解需求
2. **任务拆分**：开发团队估算工作量（使用斐波那契点数）
3. **开发**：2 周一个 Sprint
4. **代码审查**：所有 PR 需 1 人 Approve
5. **部署**：合并到 `main` 自动部署到生产环境

### 6.3 Git 工作流

**分支策略**：
- `main`：生产环境（受保护）
- `develop`：开发环境
- `feature/*`：功能分支
- `hotfix/*`：紧急修复

**Commit 规范**（Conventional Commits）：
```
feat: 添加用户注册功能
fix: 修复登录接口 500 错误
docs: 更新 API 文档
test: 添加用户注册测试用例
refactor: 重构数据库查询逻辑
```

---

## 7. 成功指标（Success Metrics）

### 7.1 产品指标

| 指标 | 目标 | 测量方式 |
|------|------|---------|
| **代码审查覆盖率** | 80%+ PR 被审查 | GitHub API |
| **审查响应时间** | < 1 分钟 | 系统日志 |
| **用户留存率** | 60%（30 天） | Mixpanel |
| **NPS 分数** | > 50 | 用户调研 |

### 7.2 技术指标

| 指标 | 目标 | 监控工具 |
|------|------|---------|
| **可用性** | 99.9% uptime | UptimeRobot |
| **错误率** | < 0.1% | Sentry |
| **API 响应时间** | P95 < 200ms | Grafana |
| **测试覆盖率** | > 80% | Coverage.py |

---

## 8. 风险与依赖（Risks & Dependencies）

### 8.1 技术风险

| 风险 | 影响 | 缓解措施 |
|------|------|---------|
| **LLM API 不稳定** | 🔴 高 | 实现重试机制 + 降级方案 |
| **数据库性能瓶颈** | 🟡 中 | 使用读写分离 + 缓存 |
| **第三方服务故障** | 🟡 中 | 熔断器 + 优雅降级 |

### 8.2 外部依赖

| 依赖 | 关键性 | 备选方案 |
|------|--------|---------|
| **Anthropic API** | 🔴 关键 | OpenAI GPT-4 |
| **GitHub API** | 🔴 关键 | GitLab（如需迁移）|
| **Vercel** | 🟡 重要 | Netlify / Cloudflare Pages |

---

## 9. 参考资料（References）

### 9.1 技术文档

- [FastAPI 官方文档](https://fastapi.tiangolo.com/)
- [Next.js 14 文档](https://nextjs.org/docs)
- [PostgreSQL 最佳实践](https://wiki.postgresql.org/wiki/Don%27t_Do_This)
- [Anthropic Prompt Engineering](https://docs.anthropic.com/claude/docs)

### 9.2 相关项目

- [SonarQube](https://www.sonarqube.org/)：传统代码质量分析
- [CodeRabbit](https://coderabbit.ai/)：AI 代码审查竞品
- [GitHub Copilot](https://github.com/features/copilot)：AI 辅助编程

---

## 10. 变更日志（Change Log）

| 日期 | 版本 | 变更内容 |
|------|------|---------|
| 2024-11-22 | v1.0.0 | 初始版本 |

---

**填写说明**：
1. 删除所有示例内容，替换为你的实际项目信息
2. 标记为"TODO"的部分需要后续补充
3. 保持此文档更新，作为项目的"北极星"
