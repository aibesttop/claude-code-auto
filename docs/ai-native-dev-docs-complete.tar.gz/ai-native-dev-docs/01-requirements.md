# 01 - Requirements Specification（需求规格说明）

> **目的**：用机器可读的方式精确描述每个功能的输入、输出、异常和测试用例

---

## 📋 文档说明

### 编写原则

1. **明确性**：每个需求必须包含输入/输出规格（YAML 格式）
2. **可测试性**：必须提供完整的测试用例代码
3. **无歧义**：使用具体数值、格式、枚举，避免"合理的"、"适当的"等模糊词汇
4. **完整性**：覆盖正常流程、边界条件、异常情况

### 需求编号规则

- `FR-XXX`：功能需求（Functional Requirement）
- `NFR-XXX`：非功能需求（Non-Functional Requirement）
- `DR-XXX`：数据需求（Data Requirement）

---

## 📌 需求模板

每个功能需求使用以下模板：

```markdown
### FR-XXX: [功能名称]

#### 输入/输出规格
```yaml
endpoint: [HTTP 方法] [路径]
input:
  [参数名]: [类型] ([约束])
  
success_output:
  status: [状态码]
  body:
    [字段名]: [类型]
    
error_outputs:
  - status: [状态码]
    condition: [触发条件]
    body: {error: "[错误代码]", message: "[错误信息]"}
```

#### 业务规则
1. [规则 1]
2. [规则 2]

#### 边界条件
- [边界 1]
- [边界 2]

#### 依赖
- 前置条件：[前置需求]
- 外部服务：[依赖的服务]
- 共享模块：[依赖的代码模块]

#### 测试用例
```python
# [测试文件名]

def test_[场景]():
    """[测试描述]"""
    # 测试代码
```

#### 性能要求
- [性能指标]

#### 安全要求
- [安全措施]
```

---

## 🎯 功能需求（Functional Requirements）

### FR-001: 用户注册

#### 输入/输出规格

```yaml
endpoint: POST /api/v1/auth/register
authentication: none

input:
  email:
    type: string
    format: email
    max_length: 255
    required: true
    example: "user@example.com"
    
  password:
    type: string
    min_length: 8
    max_length: 128
    pattern: "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$"
    required: true
    description: "必须包含：大写字母、小写字母、数字、特殊字符"
    example: "SecureP@ss123"
    
  username:
    type: string
    min_length: 3
    max_length: 20
    pattern: "^[a-zA-Z0-9_]+$"
    required: true
    example: "john_doe"

success_output:
  status: 201
  body:
    user_id:
      type: uuid
      example: "550e8400-e29b-41d4-a716-446655440000"
    email:
      type: string
      example: "user@example.com"
    username:
      type: string
      example: "john_doe"
    email_verified:
      type: boolean
      value: false
    created_at:
      type: string
      format: iso8601
      example: "2024-11-22T10:30:00Z"
    
error_outputs:
  - status: 400
    condition: "邮箱已被注册"
    body:
      error: "EMAIL_ALREADY_EXISTS"
      message: "This email is already registered"
      field: "email"
  
  - status: 400
    condition: "用户名已被占用"
    body:
      error: "USERNAME_TAKEN"
      message: "This username is not available"
      field: "username"
      
  - status: 400
    condition: "密码不符合要求"
    body:
      error: "WEAK_PASSWORD"
      message: "Password does not meet security requirements"
      requirements:
        - "At least 8 characters"
        - "At least one uppercase letter"
        - "At least one lowercase letter"
        - "At least one digit"
        - "At least one special character (@$!%*?&)"
      field: "password"
      
  - status: 400
    condition: "输入格式无效"
    body:
      error: "VALIDATION_ERROR"
      message: "Input validation failed"
      details:
        - field: "email"
          message: "Invalid email format"
          
  - status: 429
    condition: "超过频率限制"
    body:
      error: "RATE_LIMIT_EXCEEDED"
      message: "Too many registration attempts. Please try again later."
      retry_after: 300  # 秒
      
  - status: 500
    condition: "服务器内部错误"
    body:
      error: "INTERNAL_ERROR"
      message: "An unexpected error occurred. Please try again later."
```

#### 业务规则

1. **邮箱唯一性**：
   - 邮箱必须全局唯一
   - 比对时忽略大小写（`test@example.com` 等同于 `TEST@example.com`）
   - 存储时保留原始大小写

2. **密码存储**：
   - 使用 bcrypt 哈希（cost factor = 12）
   - 原始密码不存储、不记录日志、不出现在错误信息中

3. **邮箱验证**：
   - 注册成功后自动发送验证邮件（异步队列）
   - 邮件发送失败不影响注册成功
   - 用户状态标记为 `email_verified=false`

4. **用户名规则**：
   - 仅允许字母、数字、下划线
   - 不区分大小写（`John_Doe` 等同于 `john_doe`）
   - 可后续修改

#### 边界条件

1. **并发注册**：
   - 两个用户同时注册相同邮箱：先到先得，后者返回 `409 Conflict`
   - 使用数据库唯一约束 + 事务保证原子性

2. **频率限制**：
   - 同一 IP 地址：5 分钟内最多 3 次注册尝试
   - 同一邮箱：24 小时内最多 5 次注册尝试（防止邮箱验证滥用）

3. **输入边界**：
   - 邮箱最长 255 字符（符合 RFC 5321）
   - 用户名最长 20 字符（数据库索引优化考虑）
   - 密码最长 128 字符（bcrypt 限制）

4. **特殊字符**：
   - 邮箱支持国际化域名（IDN）
   - 用户名不支持 emoji 或特殊字符

#### 依赖

**前置条件**：
- 数据库表 `users` 已创建并迁移
- Redis 已配置（用于频率限制）
- 邮件服务已配置（SendGrid API Key）

**外部服务**：
- SendGrid API（邮件发送）
- Redis（频率限制、会话存储）

**共享模块**：
- `src.utils.validators.validate_email(email: str) -> bool`
- `src.utils.crypto.hash_password(password: str) -> str`
- `src.utils.crypto.verify_password(password: str, hash: str) -> bool`

#### 测试用例

```python
# tests/integration/test_auth_register.py

import pytest
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session
from src.models.user import User
from src.main import app

client = TestClient(app)

def test_register_success(db: Session):
    """正常注册流程"""
    response = client.post("/api/v1/auth/register", json={
        "email": "newuser@example.com",
        "password": "SecureP@ss123",
        "username": "newuser"
    })
    
    assert response.status_code == 201
    data = response.json()
    
    # 验证响应结构
    assert "user_id" in data
    assert data["email"] == "newuser@example.com"
    assert data["username"] == "newuser"
    assert data["email_verified"] is False
    assert "created_at" in data
    
    # 验证数据库记录
    user = db.query(User).filter(User.email == "newuser@example.com").first()
    assert user is not None
    assert user.email_verified is False
    assert user.password_hash.startswith("$2b$")  # bcrypt 前缀


def test_register_duplicate_email(db: Session):
    """重复邮箱注册应返回 400"""
    # 第一次注册
    client.post("/api/v1/auth/register", json={
        "email": "duplicate@example.com",
        "password": "SecureP@ss123",
        "username": "user1"
    })
    
    # 第二次注册（不同大小写）
    response = client.post("/api/v1/auth/register", json={
        "email": "DUPLICATE@example.com",  # 大小写不同
        "password": "SecureP@ss123",
        "username": "user2"
    })
    
    assert response.status_code == 400
    assert response.json()["error"] == "EMAIL_ALREADY_EXISTS"
    assert response.json()["field"] == "email"


def test_register_duplicate_username(db: Session):
    """重复用户名应返回 400"""
    client.post("/api/v1/auth/register", json={
        "email": "user1@example.com",
        "password": "SecureP@ss123",
        "username": "duplicate_user"
    })
    
    response = client.post("/api/v1/auth/register", json={
        "email": "user2@example.com",
        "password": "SecureP@ss123",
        "username": "Duplicate_User"  # 大小写不同
    })
    
    assert response.status_code == 400
    assert response.json()["error"] == "USERNAME_TAKEN"


def test_register_weak_password():
    """弱密码应返回 400 及详细要求"""
    test_cases = [
        ("12345678", "无大写字母、特殊字符"),
        ("password", "无大写字母、数字、特殊字符"),
        ("Pass123", "少于 8 字符"),
        ("PASSWORD123!", "无小写字母"),
        ("Password123", "无特殊字符"),
    ]
    
    for password, description in test_cases:
        response = client.post("/api/v1/auth/register", json={
            "email": f"test_{password}@example.com",
            "password": password,
            "username": f"user_{password}"
        })
        
        assert response.status_code == 400, f"失败场景：{description}"
        data = response.json()
        assert data["error"] == "WEAK_PASSWORD"
        assert "requirements" in data
        assert len(data["requirements"]) > 0


def test_register_invalid_email_format():
    """无效邮箱格式应返回 400"""
    invalid_emails = [
        "notanemail",
        "@example.com",
        "user@",
        "user @example.com",
        "user@.com",
    ]
    
    for email in invalid_emails:
        response = client.post("/api/v1/auth/register", json={
            "email": email,
            "password": "SecureP@ss123",
            "username": "testuser"
        })
        
        assert response.status_code == 400
        assert response.json()["error"] == "VALIDATION_ERROR"


def test_register_invalid_username():
    """无效用户名应返回 400"""
    invalid_usernames = [
        "ab",  # 太短
        "a" * 21,  # 太长
        "user@name",  # 特殊字符
        "user name",  # 空格
        "用户名",  # 中文
    ]
    
    for username in invalid_usernames:
        response = client.post("/api/v1/auth/register", json={
            "email": f"{username}@example.com",
            "password": "SecureP@ss123",
            "username": username
        })
        
        assert response.status_code == 400


def test_register_rate_limit(db: Session):
    """超过频率限制应返回 429"""
    # 同一 IP 连续注册 4 次
    for i in range(4):
        response = client.post("/api/v1/auth/register", json={
            "email": f"ratelimit{i}@example.com",
            "password": "SecureP@ss123",
            "username": f"ratelimit{i}"
        })
        
        if i < 3:
            assert response.status_code == 201, f"第 {i+1} 次应成功"
        else:
            assert response.status_code == 429, "第 4 次应被限制"
            assert response.json()["error"] == "RATE_LIMIT_EXCEEDED"
            assert response.json()["retry_after"] == 300


def test_register_concurrent_same_email(db: Session):
    """并发注册相同邮箱，只有一个成功"""
    import concurrent.futures
    
    def register():
        return client.post("/api/v1/auth/register", json={
            "email": "concurrent@example.com",
            "password": "SecureP@ss123",
            "username": f"user_{random.randint(1000, 9999)}"
        })
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
        futures = [executor.submit(register) for _ in range(5)]
        responses = [f.result() for f in futures]
    
    # 只有一个 201，其他都是 400
    success_count = sum(1 for r in responses if r.status_code == 201)
    assert success_count == 1
    
    error_count = sum(1 for r in responses if r.status_code == 400)
    assert error_count == 4


def test_register_email_verification_sent(db: Session, mock_sendgrid):
    """注册成功后应发送验证邮件"""
    response = client.post("/api/v1/auth/register", json={
        "email": "verify@example.com",
        "password": "SecureP@ss123",
        "username": "verifyuser"
    })
    
    assert response.status_code == 201
    
    # 验证邮件任务已入队
    # （这里假设使用 Celery，实际实现根据你的队列系统调整）
    from src.tasks.email import send_verification_email
    assert send_verification_email.delay.called


def test_register_password_not_in_logs(caplog):
    """密码不应出现在日志中"""
    client.post("/api/v1/auth/register", json={
        "email": "logtest@example.com",
        "password": "SecretP@ss123",
        "username": "logtest"
    })
    
    # 检查所有日志
    for record in caplog.records:
        assert "SecretP@ss123" not in record.message
        assert "password" not in record.message.lower()
```

#### 性能要求

| 指标 | 目标 | 测量方式 |
|------|------|---------|
| **响应时间** | P50 < 100ms, P95 < 200ms, P99 < 500ms | Locust 负载测试 |
| **吞吐量** | 支持 100 req/s | K6 压测 |
| **数据库查询** | < 20ms（使用索引） | EXPLAIN ANALYZE |
| **并发** | 支持 1000 并发连接 | 压力测试 |

**优化措施**：
- 邮箱和用户名字段创建唯一索引
- 使用数据库连接池（pool size: 20）
- 邮件发送使用异步队列（不阻塞响应）

#### 安全要求

1. **SQL 注入防护**：
   - 使用 SQLAlchemy ORM 的参数化查询
   - 禁止字符串拼接 SQL

2. **XSS 防护**：
   - FastAPI 自动转义输出
   - 用户名和邮箱存储前无需额外过滤

3. **密码安全**：
   - 使用 bcrypt（cost=12）
   - 原始密码不存储、不记录、不传输明文

4. **频率限制**：
   - 基于 IP 的全局限制（5 分钟 3 次）
   - 基于邮箱的限制（24 小时 5 次）

5. **日志脱敏**：
   - 自动移除密码字段
   - PII（个人身份信息）字段需脱敏（邮箱显示为 `u***@example.com`）

---

### FR-002: 用户登录

#### 输入/输出规格

```yaml
endpoint: POST /api/v1/auth/login
authentication: none

input:
  email:
    type: string
    format: email
    required: true
    example: "user@example.com"
    
  password:
    type: string
    required: true
    example: "SecureP@ss123"
    
  remember_me:
    type: boolean
    required: false
    default: false
    description: "是否记住登录状态（延长 Refresh Token 有效期）"

success_output:
  status: 200
  body:
    access_token:
      type: string
      format: jwt
      expires_in: 900  # 15 分钟
      example: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
      
    refresh_token:
      type: string
      format: jwt
      expires_in: 604800  # 7 天（remember_me=false）或 2592000（30 天，remember_me=true）
      example: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
      
    token_type:
      type: string
      value: "Bearer"
      
    user:
      type: object
      properties:
        user_id: uuid
        email: string
        username: string
        email_verified: boolean

error_outputs:
  - status: 401
    condition: "邮箱或密码错误"
    body:
      error: "INVALID_CREDENTIALS"
      message: "Invalid email or password"
      
  - status: 401
    condition: "账号被禁用"
    body:
      error: "ACCOUNT_DISABLED"
      message: "Your account has been disabled. Please contact support."
      
  - status: 429
    condition: "登录尝试过多"
    body:
      error: "TOO_MANY_ATTEMPTS"
      message: "Too many failed login attempts. Please try again later."
      retry_after: 600  # 10 分钟
```

#### 业务规则

1. **认证流程**：
   - 根据邮箱查找用户（不区分大小写）
   - 使用 bcrypt 验证密码
   - 验证失败不透露具体原因（邮箱不存在 vs 密码错误）

2. **Token 机制**：
   - Access Token：15 分钟有效期，用于 API 调用
   - Refresh Token：7 天有效期（可选 30 天）
   - 使用 RS256 签名（非对称加密）

3. **失败处理**：
   - 5 次失败后锁定账号 10 分钟
   - 记录失败次数到 Redis（TTL: 10min）

4. **安全日志**：
   - 记录登录 IP、User-Agent、时间戳
   - 异常登录发送邮件通知

#### 测试用例

```python
# tests/integration/test_auth_login.py

def test_login_success(db: Session, registered_user):
    """正常登录流程"""
    response = client.post("/api/v1/auth/login", json={
        "email": registered_user.email,
        "password": "SecureP@ss123"
    })
    
    assert response.status_code == 200
    data = response.json()
    
    assert "access_token" in data
    assert "refresh_token" in data
    assert data["token_type"] == "Bearer"
    assert data["user"]["email"] == registered_user.email


def test_login_invalid_password(registered_user):
    """错误密码应返回 401"""
    response = client.post("/api/v1/auth/login", json={
        "email": registered_user.email,
        "password": "WrongPassword123!"
    })
    
    assert response.status_code == 401
    assert response.json()["error"] == "INVALID_CREDENTIALS"


def test_login_nonexistent_email():
    """不存在的邮箱应返回 401（不透露邮箱是否存在）"""
    response = client.post("/api/v1/auth/login", json={
        "email": "nonexistent@example.com",
        "password": "SecureP@ss123"
    })
    
    assert response.status_code == 401
    assert response.json()["error"] == "INVALID_CREDENTIALS"


def test_login_rate_limit(registered_user):
    """5 次失败后应锁定"""
    for i in range(6):
        response = client.post("/api/v1/auth/login", json={
            "email": registered_user.email,
            "password": "WrongPassword"
        })
        
        if i < 5:
            assert response.status_code == 401
        else:
            assert response.status_code == 429
            assert response.json()["error"] == "TOO_MANY_ATTEMPTS"


def test_login_remember_me(registered_user):
    """remember_me=true 应延长 Refresh Token 有效期"""
    response = client.post("/api/v1/auth/login", json={
        "email": registered_user.email,
        "password": "SecureP@ss123",
        "remember_me": True
    })
    
    refresh_token = response.json()["refresh_token"]
    payload = jwt.decode(refresh_token, verify=False)
    
    # 验证有效期为 30 天
    exp = payload["exp"]
    iat = payload["iat"]
    assert (exp - iat) == 2592000  # 30 天
```

---

## 📊 非功能需求（Non-Functional Requirements）

### NFR-001: 性能要求

| 端点 | P50 | P95 | P99 |
|------|-----|-----|-----|
| `POST /auth/register` | < 80ms | < 150ms | < 300ms |
| `POST /auth/login` | < 50ms | < 100ms | < 200ms |
| `GET /users/:id` | < 30ms | < 60ms | < 120ms |

**测试方法**：
```bash
# 使用 Locust 进行负载测试
locust -f tests/performance/load_test.py \
    --users 1000 \
    --spawn-rate 50 \
    --run-time 5m \
    --host https://api.example.com
```

### NFR-002: 可用性要求

- **Uptime**：99.9%（月均停机时间 < 43 分钟）
- **故障恢复**：MTTR（平均修复时间）< 15 分钟
- **数据备份**：每日全量备份 + 实时增量备份

### NFR-003: 安全要求

- **传输加密**：TLS 1.3
- **存储加密**：敏感数据 AES-256
- **认证**：JWT（RS256）
- **授权**：RBAC
- **审计**：所有敏感操作记录日志

---

## 🗄️ 数据需求（Data Requirements）

### DR-001: 用户数据模型

```python
# src/models/user.py

from sqlalchemy import Column, String, Boolean, DateTime, Enum
from sqlalchemy.dialects.postgresql import UUID
import uuid
from datetime import datetime

class User(Base):
    __tablename__ = "users"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email = Column(String(255), unique=True, nullable=False, index=True)
    email_verified = Column(Boolean, default=False, nullable=False)
    username = Column(String(20), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    
    # 审计字段
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_login_at = Column(DateTime, nullable=True)
    
    # 软删除
    deleted_at = Column(DateTime, nullable=True)
    
    # 索引
    __table_args__ = (
        Index('idx_email_lower', func.lower(email)),  # 不区分大小写查询
        Index('idx_username_lower', func.lower(username)),
    )
```

**迁移脚本**：
```python
# migrations/versions/001_create_users_table.py

def upgrade():
    op.create_table(
        'users',
        sa.Column('id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('email', sa.String(length=255), nullable=False),
        sa.Column('email_verified', sa.Boolean(), nullable=False),
        sa.Column('username', sa.String(length=20), nullable=False),
        sa.Column('password_hash', sa.String(length=255), nullable=False),
        sa.Column('created_at', sa.DateTime(), nullable=False),
        sa.Column('updated_at', sa.DateTime(), nullable=False),
        sa.Column('last_login_at', sa.DateTime(), nullable=True),
        sa.Column('deleted_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index('idx_email_lower', 'users', [sa.text('LOWER(email)')], unique=True)
    op.create_index('idx_username_lower', 'users', [sa.text('LOWER(username)')], unique=True)
```

---

## ✅ 验收标准（Acceptance Criteria）

每个需求完成后，必须满足以下条件：

### 代码层面
- [ ] 所有功能已实现
- [ ] 代码通过 Linting（Black, Flake8, Mypy）
- [ ] 类型注解完整（Mypy strict mode）
- [ ] 无安全漏洞（Bandit 扫描）

### 测试层面
- [ ] 所有测试用例通过
- [ ] 代码覆盖率 ≥ 80%
- [ ] 性能测试达标（P95 < 目标值）
- [ ] 安全测试通过（OWASP Top 10）

### 文档层面
- [ ] API 文档已更新（OpenAPI）
- [ ] 数据库迁移脚本已编写
- [ ] README 已更新

---

## 📝 变更日志

| 日期 | 版本 | 变更内容 |
|------|------|---------|
| 2024-11-22 | v1.0.0 | 初始版本，定义 FR-001, FR-002 |

---

**填写说明**：
1. 每个新功能复制"需求模板"并填写
2. 测试用例必须是可执行的代码
3. 所有 YAML 规格必须精确（类型、约束、示例）
4. 边界条件要覆盖所有异常场景
