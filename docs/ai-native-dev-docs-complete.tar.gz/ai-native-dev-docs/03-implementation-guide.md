# 03 - Implementation Guide（实现指南）

> **目的**：定义编码规范、错误处理模式、性能优化策略，确保 AI 生成的代码符合项目标准

---

## 🚀 开发环境设置

### 1.1 自动化设置脚本

```bash
#!/bin/bash
# scripts/setup.sh - 一键设置开发环境

set -e  # 遇错退出
set -u  # 未定义变量报错

echo "🔧 Setting up development environment..."

# 1. 检查依赖
echo "📋 Checking dependencies..."
command -v python3.11 >/dev/null 2>&1 || {
    echo "❌ Python 3.11+ required. Install from https://www.python.org"
    exit 1
}
command -v docker >/dev/null 2>&1 || {
    echo "❌ Docker required. Install from https://www.docker.com"
    exit 1
}
command -v docker-compose >/dev/null 2>&1 || {
    echo "❌ Docker Compose required."
    exit 1
}

# 2. 创建虚拟环境
echo "🐍 Creating virtual environment..."
python3.11 -m venv .venv
source .venv/bin/activate

# 3. 升级 pip
echo "📦 Upgrading pip..."
pip install --upgrade pip

# 4. 安装依赖
echo "📦 Installing dependencies..."
pip install -r requirements.txt
pip install -r requirements-dev.txt

# 5. 复制环境变量模板
if [ ! -f .env ]; then
    echo "📝 Creating .env file..."
    cp .env.example .env
    echo "⚠️  Please edit .env with your actual configuration"
fi

# 6. 启动数据库和 Redis
echo "🐳 Starting Docker services..."
docker-compose up -d postgres redis

# 等待数据库启动
echo "⏳ Waiting for PostgreSQL to be ready..."
until docker-compose exec -T postgres pg_isready -U user > /dev/null 2>&1; do
    sleep 1
done

# 7. 运行数据库迁移
echo "🗄️  Running database migrations..."
alembic upgrade head

# 8. 加载测试数据（可选）
read -p "Load seed data for testing? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    python scripts/seed_data.py
fi

# 9. 安装 pre-commit hooks
echo "🪝 Installing pre-commit hooks..."
pre-commit install

echo ""
echo "✅ Setup complete!"
echo ""
echo "To start the development server:"
echo "  source .venv/bin/activate"
echo "  uvicorn src.main:app --reload"
echo ""
echo "To run tests:"
echo "  pytest tests/"
```

### 1.2 环境变量配置

```bash
# .env.example

# Application
APP_NAME=MyAPI
APP_VERSION=1.0.0
ENVIRONMENT=development  # development | staging | production

# Server
HOST=0.0.0.0
PORT=8000
WORKERS=4

# Database
DATABASE_URL=postgresql+asyncpg://user:password@localhost:5432/mydb
DATABASE_POOL_SIZE=20
DATABASE_MAX_OVERFLOW=10

# Redis
REDIS_URL=redis://localhost:6379/0
REDIS_MAX_CONNECTIONS=50

# JWT
JWT_SECRET_KEY=your-secret-key-change-in-production
JWT_ALGORITHM=RS256
JWT_ACCESS_TOKEN_EXPIRE_MINUTES=15
JWT_REFRESH_TOKEN_EXPIRE_DAYS=7

# Email (SendGrid)
SENDGRID_API_KEY=your-sendgrid-api-key
FROM_EMAIL=noreply@example.com

# CORS
CORS_ORIGINS=http://localhost:3000,https://example.com

# Rate Limiting
RATE_LIMIT_PER_MINUTE=60

# Logging
LOG_LEVEL=INFO  # DEBUG | INFO | WARNING | ERROR
LOG_FORMAT=json  # json | text

# Monitoring
SENTRY_DSN=your-sentry-dsn
SENTRY_ENVIRONMENT=development
```

---

## 📝 编码规范

### 2.1 Python 代码风格

#### 格式化工具配置

```toml
# pyproject.toml

[tool.black]
line-length = 100
target-version = ['py311']
include = '\.pyi?$'
exclude = '''
/(
    \.git
  | \.venv
  | migrations
  | __pycache__
)/
'''

[tool.isort]
profile = "black"
line_length = 100
skip_gitignore = true

[tool.mypy]
python_version = "3.11"
strict = true
warn_return_any = true
warn_unused_configs = true
disallow_untyped_defs = true
disallow_incomplete_defs = true
check_untyped_defs = true
no_implicit_optional = true
warn_redundant_casts = true
warn_unused_ignores = true

[tool.pytest.ini_options]
testpaths = ["tests"]
python_files = "test_*.py"
python_classes = "Test*"
python_functions = "test_*"
addopts = "-v --cov=src --cov-report=html --cov-report=term"

[tool.coverage.run]
source = ["src"]
omit = ["tests/*", "migrations/*"]

[tool.coverage.report]
exclude_lines = [
    "pragma: no cover",
    "def __repr__",
    "raise AssertionError",
    "raise NotImplementedError",
    "if __name__ == .__main__.:",
    "if TYPE_CHECKING:",
]
```

#### 命名规范

```python
# ✅ 正确示例

# 变量和函数：snake_case
user_email = "test@example.com"
def calculate_total_price():
    pass

# 类：PascalCase
class UserService:
    pass

# 常量：UPPER_SNAKE_CASE
MAX_RETRY_COUNT = 3
DEFAULT_TIMEOUT = 30

# 私有成员：前缀 _
class MyClass:
    def __init__(self):
        self._internal_state = {}
    
    def _internal_method(self):
        pass

# 类型变量：PascalCase with T prefix
from typing import TypeVar
T = TypeVar('T')
UserT = TypeVar('UserT', bound='User')

# ❌ 错误示例

# 避免单字母变量（除了循环）
x = get_user()  # 不好
user = get_user()  # 好

# 避免匈牙利命名法
strUsername = "john"  # 不好
username = "john"  # 好

# 避免缩写（除非广为人知）
usr_mgr = UserManager()  # 不好
user_manager = UserManager()  # 好
```

#### 类型注解（强制）

```python
# ✅ 完整类型注解

from typing import Optional, List, Dict, Any, Union
from datetime import datetime

def get_user_by_id(
    user_id: str,
    include_deleted: bool = False
) -> Optional[User]:
    """
    根据 ID 获取用户
    
    Args:
        user_id: 用户 UUID
        include_deleted: 是否包含已删除用户
        
    Returns:
        User 对象，如果不存在则返回 None
    """
    pass

async def create_user(
    data: UserCreateSchema
) -> tuple[User, str]:
    """
    创建新用户
    
    Returns:
        (用户对象, 验证 Token)
    """
    pass

# 复杂类型
def process_data(
    items: List[Dict[str, Any]]
) -> Dict[str, Union[int, str]]:
    pass

# 泛型
from typing import TypeVar, Generic

T = TypeVar('T')

class Repository(Generic[T]):
    def get(self, id: str) -> Optional[T]:
        pass
    
    def list(self) -> List[T]:
        pass
```

### 2.2 Docstring 规范（Google Style）

```python
def calculate_discount(
    price: Decimal,
    discount_rate: float,
    user_tier: str,
    promo_code: Optional[str] = None
) -> Decimal:
    """
    计算折扣后的价格
    
    根据用户等级和促销码计算最终价格。Premium 用户享受额外 5% 折扣。
    
    Args:
        price: 原价，必须大于 0
        discount_rate: 基础折扣率，范围 0.0 ~ 1.0（0% ~ 100%）
        user_tier: 用户等级，可选值：
            - "basic": 基础用户
            - "premium": 高级用户（额外 5% 折扣）
            - "enterprise": 企业用户（额外 10% 折扣）
        promo_code: 可选的促销码，格式：PROMO_XXXX
        
    Returns:
        折扣后的价格，保留 2 位小数
        
    Raises:
        ValueError: 如果 price <= 0
        ValueError: 如果 discount_rate 不在 [0, 1] 范围内
        ValueError: 如果 user_tier 不是有效值
        PromoCodeError: 如果促销码无效或已过期
        
    Example:
        >>> calculate_discount(Decimal("100.00"), 0.2, "premium")
        Decimal('75.00')
        
        >>> calculate_discount(Decimal("100.00"), 0.1, "basic", "PROMO_SUMMER")
        Decimal('80.00')
        
    Note:
        促销码折扣与用户等级折扣可以叠加，但总折扣不超过 50%
    """
    if price <= 0:
        raise ValueError("Price must be positive")
    
    if not 0 <= discount_rate <= 1:
        raise ValueError("Discount rate must be between 0 and 1")
    
    # 验证用户等级
    valid_tiers = {"basic", "premium", "enterprise"}
    if user_tier not in valid_tiers:
        raise ValueError(f"Invalid user tier. Must be one of: {valid_tiers}")
    
    # 应用基础折扣
    final_price = price * (1 - discount_rate)
    
    # 应用等级折扣
    tier_discounts = {
        "basic": 0,
        "premium": 0.05,
        "enterprise": 0.10
    }
    final_price *= (1 - tier_discounts[user_tier])
    
    # 应用促销码
    if promo_code:
        promo_discount = validate_and_get_promo_discount(promo_code)
        final_price *= (1 - promo_discount)
    
    # 确保总折扣不超过 50%
    minimum_price = price * 0.5
    if final_price < minimum_price:
        final_price = minimum_price
    
    return final_price.quantize(Decimal("0.01"))
```

---

## 🔧 错误处理模式

### 3.1 自定义异常体系

```python
# src/core/exceptions.py

from typing import Optional, Dict, Any

class AppException(Exception):
    """应用基础异常"""
    
    def __init__(
        self,
        message: str,
        error_code: str,
        status_code: int = 500,
        details: Optional[Dict[str, Any]] = None
    ):
        self.message = message
        self.error_code = error_code
        self.status_code = status_code
        self.details = details or {}
        super().__init__(message)

# 具体异常类型
class ValidationError(AppException):
    """输入验证错误（400）"""
    def __init__(self, message: str, details: Optional[Dict] = None):
        super().__init__(
            message=message,
            error_code="VALIDATION_ERROR",
            status_code=400,
            details=details
        )

class AuthenticationError(AppException):
    """认证失败（401）"""
    def __init__(self, message: str = "Authentication failed"):
        super().__init__(
            message=message,
            error_code="AUTHENTICATION_ERROR",
            status_code=401
        )

class AuthorizationError(AppException):
    """权限不足（403）"""
    def __init__(self, message: str = "Insufficient permissions"):
        super().__init__(
            message=message,
            error_code="AUTHORIZATION_ERROR",
            status_code=403
        )

class NotFoundError(AppException):
    """资源不存在（404）"""
    def __init__(self, resource: str, identifier: str):
        super().__init__(
            message=f"{resource} not found",
            error_code="NOT_FOUND",
            status_code=404,
            details={"resource": resource, "identifier": identifier}
        )

class ConflictError(AppException):
    """资源冲突（409）"""
    def __init__(self, message: str, field: Optional[str] = None):
        super().__init__(
            message=message,
            error_code="CONFLICT",
            status_code=409,
            details={"field": field} if field else {}
        )

class RateLimitError(AppException):
    """超过频率限制（429）"""
    def __init__(self, retry_after: int):
        super().__init__(
            message="Too many requests",
            error_code="RATE_LIMIT_EXCEEDED",
            status_code=429,
            details={"retry_after": retry_after}
        )
```

### 3.2 全局异常处理器

```python
# src/api/error_handlers.py

from fastapi import FastAPI, Request, status
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from sqlalchemy.exc import IntegrityError
from datetime import datetime
import uuid

from src.core.exceptions import AppException
from src.core.logging import logger

def register_exception_handlers(app: FastAPI) -> None:
    """注册全局异常处理器"""
    
    @app.exception_handler(AppException)
    async def app_exception_handler(request: Request, exc: AppException):
        """处理自定义应用异常"""
        request_id = str(uuid.uuid4())
        
        logger.error(
            "application_error",
            error_code=exc.error_code,
            status_code=exc.status_code,
            message=exc.message,
            path=str(request.url),
            request_id=request_id
        )
        
        return JSONResponse(
            status_code=exc.status_code,
            content={
                "error": exc.error_code,
                "message": exc.message,
                "details": exc.details,
                "meta": {
                    "timestamp": datetime.utcnow().isoformat(),
                    "request_id": request_id,
                    "path": str(request.url)
                }
            }
        )
    
    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(request: Request, exc: RequestValidationError):
        """处理 Pydantic 验证错误"""
        request_id = str(uuid.uuid4())
        
        errors = []
        for error in exc.errors():
            errors.append({
                "field": ".".join(str(loc) for loc in error["loc"]),
                "message": error["msg"],
                "type": error["type"]
            })
        
        logger.warning(
            "validation_error",
            errors=errors,
            path=str(request.url),
            request_id=request_id
        )
        
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content={
                "error": "VALIDATION_ERROR",
                "message": "Input validation failed",
                "details": {"errors": errors},
                "meta": {
                    "timestamp": datetime.utcnow().isoformat(),
                    "request_id": request_id
                }
            }
        )
    
    @app.exception_handler(IntegrityError)
    async def integrity_error_handler(request: Request, exc: IntegrityError):
        """处理数据库完整性错误（如唯一约束冲突）"""
        request_id = str(uuid.uuid4())
        
        # 解析错误信息，识别冲突字段
        error_msg = str(exc.orig)
        field = None
        
        if "unique constraint" in error_msg.lower():
            # 提取字段名
            if "email" in error_msg.lower():
                field = "email"
            elif "username" in error_msg.lower():
                field = "username"
        
        logger.error(
            "database_integrity_error",
            error=error_msg,
            field=field,
            path=str(request.url),
            request_id=request_id
        )
        
        return JSONResponse(
            status_code=status.HTTP_409_CONFLICT,
            content={
                "error": "CONFLICT",
                "message": f"Resource already exists" + (f": {field}" if field else ""),
                "details": {"field": field} if field else {},
                "meta": {
                    "timestamp": datetime.utcnow().isoformat(),
                    "request_id": request_id
                }
            }
        )
    
    @app.exception_handler(Exception)
    async def generic_exception_handler(request: Request, exc: Exception):
        """处理未捕获的异常"""
        request_id = str(uuid.uuid4())
        
        logger.exception(
            "unhandled_exception",
            error_type=type(exc).__name__,
            error_message=str(exc),
            path=str(request.url),
            request_id=request_id
        )
        
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "error": "INTERNAL_ERROR",
                "message": "An unexpected error occurred. Please try again later.",
                "meta": {
                    "timestamp": datetime.utcnow().isoformat(),
                    "request_id": request_id
                }
            }
        )
```

### 3.3 使用示例

```python
# src/services/user_service.py

from src.core.exceptions import ConflictError, NotFoundError, ValidationError
from src.repositories.user_repository import UserRepository

class UserService:
    def __init__(self, user_repo: UserRepository):
        self.user_repo = user_repo
    
    async def create_user(self, data: UserCreateSchema) -> User:
        """创建用户"""
        
        # 检查邮箱是否已存在
        existing_user = await self.user_repo.get_by_email(data.email)
        if existing_user:
            raise ConflictError(
                message="Email already registered",
                field="email"
            )
        
        # 检查用户名是否已存在
        existing_user = await self.user_repo.get_by_username(data.username)
        if existing_user:
            raise ConflictError(
                message="Username already taken",
                field="username"
            )
        
        # 创建用户
        user = await self.user_repo.create(data)
        return user
    
    async def get_user(self, user_id: str) -> User:
        """获取用户"""
        user = await self.user_repo.get_by_id(user_id)
        if not user:
            raise NotFoundError(resource="User", identifier=user_id)
        return user
```

---

## ⚡ 性能优化策略

### 4.1 数据库查询优化

```python
# ✅ 使用索引

# 确保常查询字段有索引
CREATE INDEX idx_users_email ON users(LOWER(email));
CREATE INDEX idx_users_created_at ON users(created_at DESC);

# ✅ N+1 问题解决：使用 joinedload

from sqlalchemy.orm import joinedload

# ❌ N+1 问题
users = session.query(User).all()
for user in users:
    print(user.posts)  # 每次循环都查询一次数据库

# ✅ 使用 joinedload
users = session.query(User).options(joinedload(User.posts)).all()
for user in users:
    print(user.posts)  # 一次查询获取所有数据

# ✅ 批量操作

# ❌ 逐条插入
for item in items:
    session.add(Item(name=item))
    session.commit()

# ✅ 批量插入
session.bulk_insert_mappings(Item, [{"name": item} for item in items])
session.commit()

# ✅ 分页查询（Cursor-based）

async def get_users(
    cursor: Optional[str] = None,
    limit: int = 20
) -> tuple[List[User], Optional[str]]:
    """
    使用 cursor-based 分页（比 offset 更高效）
    """
    query = select(User).order_by(User.created_at.desc())
    
    if cursor:
        # 解码 cursor（通常是 base64 编码的时间戳）
        cursor_timestamp = decode_cursor(cursor)
        query = query.where(User.created_at < cursor_timestamp)
    
    query = query.limit(limit + 1)  # 多查一条判断是否有下一页
    
    results = await session.execute(query)
    users = results.scalars().all()
    
    has_more = len(users) > limit
    if has_more:
        users = users[:limit]
        next_cursor = encode_cursor(users[-1].created_at)
    else:
        next_cursor = None
    
    return users, next_cursor
```

### 4.2 缓存策略

```python
# src/utils/cache.py

from functools import wraps
from typing import Optional, Callable
import json
import hashlib
from redis.asyncio import Redis

class CacheManager:
    def __init__(self, redis: Redis):
        self.redis = redis
    
    def cache(
        self,
        ttl: int = 300,  # 5 分钟
        key_prefix: Optional[str] = None
    ):
        """缓存装饰器"""
        def decorator(func: Callable):
            @wraps(func)
            async def wrapper(*args, **kwargs):
                # 生成缓存键
                cache_key = self._generate_key(
                    func.__name__,
                    args,
                    kwargs,
                    key_prefix
                )
                
                # 尝试从缓存获取
                cached = await self.redis.get(cache_key)
                if cached:
                    return json.loads(cached)
                
                # 执行函数
                result = await func(*args, **kwargs)
                
                # 存入缓存
                await self.redis.setex(
                    cache_key,
                    ttl,
                    json.dumps(result, default=str)
                )
                
                return result
            return wrapper
        return decorator
    
    def _generate_key(
        self,
        func_name: str,
        args: tuple,
        kwargs: dict,
        prefix: Optional[str]
    ) -> str:
        """生成缓存键"""
        key_parts = [prefix or "cache", func_name]
        
        # 参数哈希
        params = json.dumps({"args": args, "kwargs": kwargs}, sort_keys=True)
        param_hash = hashlib.md5(params.encode()).hexdigest()[:8]
        key_parts.append(param_hash)
        
        return ":".join(key_parts)
    
    async def invalidate(self, pattern: str):
        """使缓存失效"""
        keys = await self.redis.keys(pattern)
        if keys:
            await self.redis.delete(*keys)

# 使用示例
cache_manager = CacheManager(redis_client)

@cache_manager.cache(ttl=600, key_prefix="user")
async def get_user_profile(user_id: str):
    """获取用户资料（缓存 10 分钟）"""
    user = await user_repo.get_by_id(user_id)
    return user.dict()

# 更新用户后使缓存失效
async def update_user(user_id: str, data: dict):
    await user_repo.update(user_id, data)
    await cache_manager.invalidate(f"user:get_user_profile:*{user_id}*")
```

### 4.3 异步任务队列

```python
# src/tasks/email.py

from celery import Celery
from src.core.config import settings

celery_app = Celery(
    "tasks",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND
)

@celery_app.task(
    bind=True,
    max_retries=3,
    default_retry_delay=60
)
def send_verification_email(self, user_id: str, email: str):
    """
    发送验证邮件（异步任务）
    
    Args:
        self: Celery task 实例
        user_id: 用户 ID
        email: 邮箱地址
    """
    try:
        # 生成验证 Token
        token = generate_verification_token(user_id)
        
        # 发送邮件
        send_email(
            to=email,
            subject="Verify your email",
            template="verification",
            context={"token": token}
        )
        
    except Exception as exc:
        # 失败重试
        raise self.retry(exc=exc)

# 在注册流程中使用
async def register_user(data: UserCreateSchema):
    user = await user_service.create_user(data)
    
    # 异步发送邮件（不阻塞响应）
    send_verification_email.delay(
        user_id=str(user.id),
        email=user.email
    )
    
    return user
```

---

## 🧪 测试指南

### 5.1 测试文件组织

```python
# tests/conftest.py - 共享 Fixtures

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from src.main import app
from src.core.database import Base, get_db
from src.models.user import User

# 测试数据库
SQLALCHEMY_TEST_DATABASE_URL = "sqlite:///./test.db"
engine = create_engine(SQLALCHEMY_TEST_DATABASE_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

@pytest.fixture(scope="function")
def db():
    """创建测试数据库"""
    Base.metadata.create_all(bind=engine)
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()
        Base.metadata.drop_all(bind=engine)

@pytest.fixture(scope="function")
def client(db):
    """测试客户端"""
    def override_get_db():
        try:
            yield db
        finally:
            pass
    
    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as c:
        yield c

@pytest.fixture
def registered_user(db):
    """预注册用户"""
    user = User(
        email="test@example.com",
        username="testuser",
        password_hash=hash_password("SecureP@ss123"),
        email_verified=True
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user

@pytest.fixture
def auth_headers(client, registered_user):
    """认证请求头"""
    response = client.post("/api/v1/auth/login", json={
        "email": "test@example.com",
        "password": "SecureP@ss123"
    })
    token = response.json()["access_token"]
    return {"Authorization": f"Bearer {token}"}
```

### 5.2 单元测试示例

```python
# tests/unit/test_validators.py

import pytest
from src.utils.validators import validate_email, validate_password

class TestEmailValidator:
    """邮箱验证器测试"""
    
    def test_valid_email(self):
        """有效邮箱"""
        assert validate_email("test@example.com") is True
        assert validate_email("user+tag@domain.co.uk") is True
    
    def test_invalid_email(self):
        """无效邮箱"""
        assert validate_email("notanemail") is False
        assert validate_email("@example.com") is False
        assert validate_email("user@") is False
    
    @pytest.mark.parametrize("email", [
        "test@example.com",
        "user.name@example.com",
        "user+tag@example.co.uk"
    ])
    def test_valid_emails_parametrized(self, email):
        """参数化测试：有效邮箱"""
        assert validate_email(email) is True


class TestPasswordValidator:
    """密码验证器测试"""
    
    def test_strong_password(self):
        """强密码"""
        assert validate_password("SecureP@ss123") == (True, [])
    
    def test_weak_passwords(self):
        """弱密码及错误原因"""
        result, errors = validate_password("12345678")
        assert result is False
        assert "uppercase" in " ".join(errors).lower()
        
        result, errors = validate_password("Password")
        assert result is False
        assert "digit" in " ".join(errors).lower()
```

### 5.3 集成测试示例

```python
# tests/integration/test_auth_flow.py

class TestAuthenticationFlow:
    """认证流程集成测试"""
    
    def test_register_login_access_protected_route(self, client):
        """完整认证流程：注册 → 登录 → 访问受保护路由"""
        
        # 1. 注册
        register_response = client.post("/api/v1/auth/register", json={
            "email": "newuser@example.com",
            "password": "SecureP@ss123",
            "username": "newuser"
        })
        assert register_response.status_code == 201
        user_id = register_response.json()["user_id"]
        
        # 2. 登录
        login_response = client.post("/api/v1/auth/login", json={
            "email": "newuser@example.com",
            "password": "SecureP@ss123"
        })
        assert login_response.status_code == 200
        access_token = login_response.json()["access_token"]
        
        # 3. 访问受保护路由
        headers = {"Authorization": f"Bearer {access_token}"}
        profile_response = client.get("/api/v1/users/me", headers=headers)
        assert profile_response.status_code == 200
        assert profile_response.json()["user_id"] == user_id
    
    def test_invalid_token_rejected(self, client):
        """无效 Token 被拒绝"""
        headers = {"Authorization": "Bearer invalid_token"}
        response = client.get("/api/v1/users/me", headers=headers)
        assert response.status_code == 401
```

---

## 📋 代码审查检查清单

提交 Pull Request 前，确保：

### 功能完整性
- [ ] 所有需求已实现
- [ ] 边界条件已处理
- [ ] 错误场景已考虑

### 代码质量
- [ ] 通过 `black --check src/`
- [ ] 通过 `flake8 src/`
- [ ] 通过 `mypy src/ --strict`
- [ ] 无 `pylint` 警告（评分 ≥ 9.0）

### 测试覆盖
- [ ] 所有新功能有单元测试
- [ ] 关键流程有集成测试
- [ ] 测试覆盖率 ≥ 80%
- [ ] 所有测试通过

### 安全性
- [ ] 无 SQL 注入风险
- [ ] 输入已验证
- [ ] 敏感信息不出现在日志
- [ ] 通过 `bandit` 扫描

### 性能
- [ ] 数据库查询使用索引
- [ ] 无 N+1 查询
- [ ] 长时间操作使用异步任务

### 文档
- [ ] 公共 API 有 docstring
- [ ] 复杂逻辑有注释
- [ ] README 已更新
- [ ] API 文档已更新

---

## 📝 变更日志

| 日期 | 版本 | 变更内容 |
|------|------|---------|
| 2024-11-22 | v1.0.0 | 初始实现指南 |
