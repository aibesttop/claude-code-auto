# 🚀 快速开始指南

## 欢迎使用 AI-Native Development 文档体系!

这套文档体系将帮助你实现从需求到可部署代码的**零人工干预**开发流程。

---

## 📦 文件说明

| 文件 | 大小 | 用途 |
|------|------|------|
| `README.md` | 5.6KB | 文档体系总览和使用说明 |
| `00-project-context.md` | 13KB | 项目愿景、约束、技术偏好 |
| `01-requirements.md` | 22KB | 功能需求规格（AI 可读） |
| `02-architecture.md` | 25KB | 系统架构和技术选型 |
| `03-implementation-guide.md` | 28KB | 编码规范和实现指南 |
| `04-quality-gates.md` | 28KB | 质量门禁和验收标准 |
| `05-ai-prompt-template.md` | 20KB | AI 任务提示词模板 |

**总计**: 约 140KB 的结构化文档

---

## 🎯 三步开始

### Step 1: 填写项目文档（1-2 天）

按顺序填写以下文档（删除示例内容，替换为你的项目信息）：

```bash
# 1. 定义项目背景和约束
编辑 00-project-context.md
├─ 项目愿景：为什么做这个项目？
├─ 技术栈：Python? Node.js? Go?
├─ 性能要求：响应时间？并发量?
└─ 预算限制：月度成本上限？

# 2. 编写功能需求（重点！）
编辑 01-requirements.md
├─ 使用 YAML 定义输入/输出
├─ 提供完整的测试用例代码
├─ 列出所有边界条件和异常
└─ 每个功能一个 FR-XXX 编号

# 3. 设计系统架构
编辑 02-architecture.md
├─ 绘制系统架构图（Mermaid）
├─ 定义目录结构（强制遵守）
├─ 设计数据库 Schema
└─ 记录技术决策（ADR）

# 4. 定义编码规范
编辑 03-implementation-guide.md
├─ 代码风格配置（Black, ESLint）
├─ 错误处理模式
├─ 性能优化策略
└─ 测试编写指南

# 5. 设置质量门禁
编辑 04-quality-gates.md
├─ 定义覆盖率阈值（建议 80%+）
├─ 配置安全扫描工具
├─ 设定性能基准
└─ 编写自动化验证脚本
```

### Step 2: 生成 AI 提示词（5 分钟）

使用 `05-ai-prompt-template.md` 中的模板创建任务提示词：

```markdown
# Task: Implement User Registration

## Context Documents
1. `/docs/00-project-context.md` - Project constraints
2. `/docs/01-requirements.md#FR-001` - Registration spec
3. `/docs/02-architecture.md` - Architecture
4. `/docs/03-implementation-guide.md` - Coding standards
5. `/docs/04-quality-gates.md` - Quality requirements

## Deliverables
- Source code in `src/api/v1/auth.py`
- Tests in `tests/integration/test_auth_register.py`
- Migration in `migrations/versions/001_create_users.py`

## Success Criteria
- [ ] All tests pass
- [ ] Coverage ≥ 80%
- [ ] All quality gates pass

## Validation
```bash
bash scripts/verify_quality.sh
```
```

### Step 3: 提交给 AI 并验证（自动化）

```bash
# 1. 提供文档和提示词给 AI（如 Claude、GPT-4、Cursor）

# 2. AI 输出代码后，运行验证脚本
bash scripts/verify_quality.sh

# 3. 如果所有门禁通过，代码即可部署！
```

---

## 💡 实际使用示例

### 场景：开发一个用户认证系统

#### 1. 填写需求文档（20 分钟）

在 `01-requirements.md` 中添加：

```yaml
# FR-001: 用户注册
endpoint: POST /api/v1/auth/register
input:
  email: string (format: email, max: 255)
  password: string (min: 8, pattern: "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d).*$")
  username: string (min: 3, max: 20)
success_output:
  status: 201
  body: {user_id: uuid, email: string, created_at: iso8601}
error_outputs:
  - status: 400, condition: "邮箱已存在"
  - status: 400, condition: "密码太弱"
```

#### 2. 生成提示词（5 分钟）

```markdown
# Task: Implement FR-001 User Registration

## Context
Read documents 00-04 for full context.

## Specific Requirements
See `01-requirements.md#FR-001` for complete specification.

## Deliverables
- `src/api/v1/auth.py` - API endpoint
- `src/services/auth_service.py` - Business logic
- `tests/integration/test_auth_register.py` - Tests

## Success Criteria
- All test cases from FR-001 pass
- Code coverage ≥ 80%
- `bash scripts/verify_quality.sh` passes
```

#### 3. AI 生成代码（几分钟）

提供给 Claude/GPT-4：

```
请阅读以下文档并实现 FR-001：

[粘贴 00-project-context.md 内容]
[粘贴 01-requirements.md#FR-001 内容]
[粘贴 02-architecture.md 相关部分]
[粘贴提示词]
```

#### 4. 自动验证（1 分钟）

```bash
# AI 生成代码后
bash scripts/verify_quality.sh

# 输出示例：
✅ Gate 1: Code Quality - Passed
✅ Gate 2: Tests (92% coverage) - Passed
✅ Gate 3: Security - Passed
⚠️  Gate 4: Performance (P95: 185ms) - Warning
✅ Gate 5: Documentation - Passed
✅ Gate 6: Docker Build - Passed
✅ Gate 7: Observability - Passed

🎉 All critical gates passed! Ready to deploy.
```

---

## 📚 核心文档详解

### 00-project-context.md - 项目全局上下文

**为什么重要**：让 AI 理解项目的"灵魂"

**关键内容**：
- **项目愿景**：一句话说明要做什么、为谁做、解决什么问题
- **技术约束**：必须用什么技术栈、不能用什么
- **性能要求**：响应时间、并发量、可用性目标
- **预算约束**：月度成本上限、优先使用免费层
- **代码风格**：命名规范、注释要求、错误处理偏好
- **不做什么**：明确当前版本不实现的功能（避免范围蔓延）

**填写示例**：
```markdown
## 核心约束
- 技术栈：Python 3.11 + FastAPI + PostgreSQL
- 性能要求：API P95 < 200ms, 支持 1000 并发
- 预算约束：月成本 < $500（使用 Vercel + Railway）
- 代码风格：Black 格式化, Mypy strict 模式

## 不做什么（v1.0）
- ❌ 不支持实时协作（类似 Google Docs）
- ❌ 不做移动端原生 APP（仅 PWA）
- ❌ 不集成支付（使用 Stripe Checkout）
```

---

### 01-requirements.md - 需求规格

**为什么重要**：这是 AI 理解"做什么"的唯一来源

**关键技巧**：
1. **用 YAML 定义接口**（比自然语言精确 10 倍）
2. **提供完整测试代码**（AI 会按测试实现功能）
3. **列出所有边界条件**（空值、并发、超时）

**好的需求 vs 坏的需求**：

```yaml
# ❌ 坏的需求（模糊）
"实现用户注册功能，验证邮箱和密码"

# ✅ 好的需求（精确）
endpoint: POST /api/v1/auth/register
input:
  email: string (format: email, max: 255, required: true)
  password: string (min: 8, pattern: "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@$!%*?&]).*$")
success_output:
  status: 201
  body: {user_id: uuid, email: string, created_at: iso8601}
error_outputs:
  - status: 400, condition: "邮箱格式无效"
  - status: 409, condition: "邮箱已存在"
  - status: 400, condition: "密码不符合要求", details: {requirements: [...]}
test_cases:
  - test_register_success()
  - test_duplicate_email_returns_409()
  - test_weak_password_rejected()
```

---

### 02-architecture.md - 架构设计

**为什么重要**：定义代码组织方式和技术选型

**关键内容**：
- **系统架构图**（Mermaid 格式，AI 可读）
- **目录结构**（强制遵守，避免 AI "创意发挥"）
- **数据库 Schema**（表结构、索引、约束）
- **API 设计原则**（RESTful? GraphQL? 版本控制?）
- **技术决策记录 (ADR)**：为什么选 FastAPI 而非 Flask?

**示例**：
```markdown
## 强制目录结构
```
src/
├── api/v1/
│   ├── auth.py        # 认证端点
│   └── users.py       # 用户端点
├── services/          # 业务逻辑
├── repositories/      # 数据访问
└── models/            # 数据模型
```

AI 必须遵守此结构，不得自行创建新目录。
```

---

### 03-implementation-guide.md - 实现指南

**为什么重要**：确保 AI 生成的代码符合项目规范

**关键内容**：
- **编码规范**：Black, Flake8, Mypy 配置
- **错误处理模式**：统一的异常体系
- **性能优化**：避免 N+1 查询、使用缓存
- **测试风格**：AAA 模式（Arrange-Act-Assert）

**示例：统一错误处理**：
```python
# ✅ 好的错误处理
class ConflictError(AppException):
    def __init__(self, message: str, field: str):
        super().__init__(
            message=message,
            error_code="CONFLICT",
            status_code=409,
            details={"field": field}
        )

# 使用
if user_exists(email):
    raise ConflictError(
        message="Email already registered",
        field="email"
    )

# ❌ 坏的错误处理
if user_exists(email):
    return {"error": "email already exists"}  # 不统一
```

---

### 04-quality-gates.md - 质量门禁

**为什么重要**：AI 的自我验证标准

**7 个门禁**：
1. **代码质量**：Black, Flake8, Mypy, Pylint
2. **测试覆盖**：≥ 80%（强制）
3. **安全扫描**：Bandit, Safety（无高危漏洞）
4. **性能基准**：Locust 负载测试
5. **文档完整性**：API 文档、Docstring
6. **部署就绪**：Docker 构建成功
7. **可观测性**：日志、指标、追踪

**自动化脚本**：
```bash
#!/bin/bash
# scripts/verify_quality.sh

# Gate 1: Code Quality
black --check src/ || exit 1
flake8 src/ || exit 1
mypy src/ --strict || exit 1

# Gate 2: Tests
pytest --cov=src --cov-fail-under=80 || exit 1

# Gate 3: Security
bandit -r src/ -ll || exit 1
safety check || exit 1

# ... 其他门禁 ...

echo "✅ All gates passed!"
```

---

### 05-ai-prompt-template.md - 提示词模板

**为什么重要**：标准化 AI 任务输入

**模板结构**：
```markdown
# Task: [任务名称]

## Context Documents
（引用上述 4 个文档）

## Task Description
（详细描述要做什么）

## Deliverables
- 具体文件清单
- 测试要求
- 文档更新

## Success Criteria
- [ ] 所有测试通过
- [ ] 覆盖率 ≥ 80%
- [ ] 质量门禁通过

## Constraints
- 不要做 X
- 必须使用 Y
- 遵循 Z 规范

## Validation
```bash
bash scripts/verify_quality.sh
```
```

---

## 🎯 成功指标

使用这套文档体系后，你应该能够：

| 指标 | 目标 |
|------|------|
| **需求→代码时间** | < 1 小时（AI 自动生成）|
| **代码质量** | Pylint 评分 ≥ 9.0 |
| **测试覆盖率** | ≥ 80%（自动达成）|
| **安全漏洞** | 0 高危（自动扫描）|
| **人工干预** | 仅代码审查阶段 |
| **迭代次数** | 1-2 次（文档足够精确）|

---

## 🆘 常见问题

### Q1: AI 生成的代码不符合要求怎么办？

**A**: 检查需求文档是否足够精确。使用 YAML 格式定义接口，提供完整的测试用例代码。如果仍然有问题，使用"迭代改进模板"（见 `05-ai-prompt-template.md`）明确指出问题。

### Q2: 文档编写需要多长时间？

**A**: 
- 首次建立：1-2 天（填写所有模板）
- 新功能：20-30 分钟（在 `01-requirements.md` 添加一个 FR-XXX）
- 维护：每月 1-2 小时（更新过时内容）

### Q3: 哪个文档最重要？

**A**: `01-requirements.md`（需求规格）。这是 AI 理解"做什么"的唯一来源。花 80% 时间在这个文档上。

### Q4: 是否支持前端开发？

**A**: 是的！文档体系是框架无关的。只需在 `00-project-context.md` 中指定前端技术栈（React、Vue、Angular），并在 `02-architecture.md` 中定义组件结构。

### Q5: 如何处理遗留代码？

**A**: 
1. 先用 AI 分析现有代码生成 `02-architecture.md`
2. 逐步填写其他文档
3. 新功能使用此体系，旧代码逐步重构

---

## 📖 推荐阅读顺序

**第一次使用**（完整阅读）：
1. `README.md` - 理解整体思路（10 分钟）
2. `00-project-context.md` - 看示例学习如何填写（20 分钟）
3. `01-requirements.md` - **重点**，学习如何写精确需求（30 分钟）
4. `05-ai-prompt-template.md` - 学习如何生成提示词（15 分钟）
5. 实践：选一个小功能（如登录）完整走一遍流程

**日常使用**（快速参考）：
1. 新功能：直接编辑 `01-requirements.md`，添加 FR-XXX
2. 生成提示词：复制 `05-ai-prompt-template.md` 中的模板
3. 提交给 AI
4. 运行 `scripts/verify_quality.sh`

---

## 🚀 下一步

1. **解压文档**：
   ```bash
   tar -xzf ai-native-dev-docs.tar.gz
   cd ai-native-dev-docs
   ```

2. **开始填写**：
   ```bash
   # 复制到你的项目
   cp -r ai-native-dev-docs /path/to/your/project/docs
   
   # 编辑 00-project-context.md
   vim docs/00-project-context.md
   ```

3. **实践**：选一个简单功能（如健康检查端点）完整走一遍流程

4. **反馈改进**：根据实际使用情况调整文档模板

---

## 💬 获取帮助

遇到问题？
- 查看文档中的 "示例" 部分
- 参考 `05-ai-prompt-template.md` 中的"常见场景"
- 逐步完善文档，每次改进一点点

记住：**文档质量 = 代码质量**。投入时间编写精确的文档，AI 会回报你高质量的代码！

---

**版本**: v1.0.0  
**创建日期**: 2024-11-22  
**作者**: AI-Native Development Team

祝你用 AI 编写出优雅的代码！🎉
