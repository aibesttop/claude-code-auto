# 02 - Architecture Design（架构设计）

> **目的**：定义系统的整体结构、技术选型、数据模型和 API 设计

---

## 📐 系统架构

### 1.1 高层架构图

```mermaid
graph TB
    subgraph "客户端层"
        Web[Web Browser]
        Mobile[Mobile App/PWA]
    end
    
    subgraph "边缘层"
        CDN[Cloudflare CDN]
        LB[Load Balancer]
    end
    
    subgraph "应用层"
        API1[API Server 1]
        API2[API Server 2]
        API3[API Server N]
    end
    
    subgraph "服务层"
        Auth[Auth Service]
        User[User Service]
        Email[Email Service]
    end
    
    subgraph "数据层"
        PG[(PostgreSQL Primary)]
        PG_RO[(PostgreSQL Replica)]
        Redis[(Redis Cache)]
        Queue[Message Queue]
    end
    
    subgraph "外部服务"
        SendGrid[SendGrid]
        Sentry[Sentry]
        Analytics[Analytics]
    end
    
    Web --> CDN
    Mobile --> CDN
    CDN --> LB
    LB --> API1
    LB --> API2
    LB --> API3
    
    API1 --> Auth
    API1 --> User
    API2 --> Auth
    API2 --> User
    
    Auth --> PG
    Auth --> Redis
    User --> PG_RO
    User --> Redis
    
    Email --> Queue
    Queue --> SendGrid
    
    API1 -.-> Sentry
    API1 -.-> Analytics
```

### 1.2 部署架构

```mermaid
graph LR
    subgraph "Production"
        FE[Vercel Edge Network]
        BE[Railway Container]
        DB[(Supabase PostgreSQL)]
        Cache[(Upstash Redis)]
    end
    
    subgraph "Staging"
        FE_STG[Vercel Preview]
        BE_STG[Railway Staging]
        DB_STG[(Staging DB)]
    end
    
    subgraph "Development"
        LOCAL[Docker Compose]
    end
    
    GitHub[GitHub Repository]
    
    GitHub -->|Push to main| FE
    GitHub -->|Push to main| BE
    GitHub -->|Push to develop| FE_STG
    GitHub -->|Push to develop| BE_STG
```

---

## 🗂️ 目录结构

### 2.1 后端项目结构（强制遵守）

```
backend/
├── src/
│   ├── api/                    # API 路由
│   │   ├── __init__.py
│   │   ├── dependencies.py     # 依赖注入
│   │   └── v1/                 # API 版本 1
│   │       ├── __init__.py
│   │       ├── auth.py         # 认证端点
│   │       ├── users.py        # 用户端点
│   │       └── health.py       # 健康检查
│   │
│   ├── core/                   # 核心配置
│   │   ├── __init__.py
│   │   ├── config.py           # 配置管理
│   │   ├── security.py         # 安全工具（JWT、密码哈希）
│   │   ├── database.py         # 数据库连接
│   │   ├── logging.py          # 日志配置
│   │   └── exceptions.py       # 自定义异常
│   │
│   ├── models/                 # 数据模型（ORM）
│   │   ├── __init__.py
│   │   ├── base.py             # Base 模型
│   │   ├── user.py             # User 模型
│   │   └── session.py          # Session 模型
│   │
│   ├── schemas/                # Pydantic 模型（API 输入/输出）
│   │   ├── __init__.py
│   │   ├── user.py             # UserCreate, UserResponse
│   │   ├── auth.py             # LoginRequest, TokenResponse
│   │   └── common.py           # 通用模型（ErrorResponse）
│   │
│   ├── services/               # 业务逻辑
│   │   ├── __init__.py
│   │   ├── auth_service.py     # 认证服务
│   │   ├── user_service.py     # 用户服务
│   │   └── email_service.py    # 邮件服务
│   │
│   ├── repositories/           # 数据访问层
│   │   ├── __init__.py
│   │   ├── user_repository.py
│   │   └── session_repository.py
│   │
│   ├── utils/                  # 工具函数
│   │   ├── __init__.py
│   │   ├── validators.py       # 输入验证
│   │   ├── crypto.py           # 加密工具
│   │   └── rate_limit.py       # 频率限制
│   │
│   ├── tasks/                  # 后台任务（Celery）
│   │   ├── __init__.py
│   │   └── email.py            # 邮件发送任务
│   │
│   └── main.py                 # FastAPI 应用入口
│
├── tests/                      # 测试目录
│   ├── unit/                   # 单元测试
│   │   ├── test_validators.py
│   │   └── test_crypto.py
│   ├── integration/            # 集成测试
│   │   ├── test_auth_register.py
│   │   └── test_auth_login.py
│   ├── e2e/                    # 端到端测试
│   │   └── test_user_journey.py
│   ├── performance/            # 性能测试
│   │   └── load_test.py
│   ├── conftest.py             # Pytest 配置
│   └── fixtures.py             # 测试数据工厂
│
├── migrations/                 # Alembic 数据库迁移
│   ├── versions/
│   │   ├── 001_create_users_table.py
│   │   └── 002_add_sessions_table.py
│   └── env.py
│
├── scripts/                    # 工具脚本
│   ├── setup.sh                # 开发环境设置
│   ├── seed_data.py            # 测试数据生成
│   ├── check_env.py            # 环境变量检查
│   └── verify_quality.sh       # 质量门禁脚本
│
├── .github/
│   └── workflows/
│       ├── ci.yml              # CI 流程
│       └── deploy.yml          # 部署流程
│
├── Dockerfile                  # Docker 镜像
├── docker-compose.yml          # 本地开发环境
├── requirements.txt            # Python 依赖
├── requirements-dev.txt        # 开发依赖
├── pyproject.toml              # 项目配置
├── .env.example                # 环境变量示例
└── README.md
```

### 2.2 前端项目结构

```
frontend/
├── src/
│   ├── app/                    # Next.js App Router
│   │   ├── layout.tsx          # 根布局
│   │   ├── page.tsx            # 首页
│   │   ├── (auth)/             # 认证路由组
│   │   │   ├── login/
│   │   │   │   └── page.tsx
│   │   │   └── register/
│   │   │       └── page.tsx
│   │   └── (dashboard)/        # 仪表板路由组
│   │       └── page.tsx
│   │
│   ├── components/             # React 组件
│   │   ├── ui/                 # shadcn/ui 组件
│   │   ├── forms/              # 表单组件
│   │   └── layouts/            # 布局组件
│   │
│   ├── lib/                    # 工具库
│   │   ├── api.ts              # API 客户端
│   │   ├── auth.ts             # 认证工具
│   │   └── utils.ts            # 通用工具
│   │
│   ├── hooks/                  # 自定义 Hooks
│   │   ├── useAuth.ts
│   │   └── useApi.ts
│   │
│   ├── stores/                 # Zustand 状态管理
│   │   ├── authStore.ts
│   │   └── userStore.ts
│   │
│   └── types/                  # TypeScript 类型
│       ├── api.ts
│       └── models.ts
│
├── public/                     # 静态资源
├── tests/
│   ├── unit/
│   └── e2e/                    # Playwright 测试
│
├── .env.local.example
├── next.config.js
├── tailwind.config.ts
├── tsconfig.json
└── package.json
```

---

## 🛠️ 技术选型决策记录（ADR）

### ADR-001: 为什么用 FastAPI 而不是 Flask？

**状态**：已接受  
**决策日期**：2024-11-20

**背景**：
需要选择 Python Web 框架构建 RESTful API。

**决策**：
使用 **FastAPI**

**理由**：
| FastAPI | Flask |
|---------|-------|
| ✅ 原生异步支持（asyncio） | ❌ 需要额外配置（Quart） |
| ✅ 自动生成 OpenAPI 文档 | ❌ 需要插件（Flask-RESTX） |
| ✅ Pydantic 数据验证 | ❌ 需要手动验证 |
| ✅ 性能更好（3-4x） | ❌ 性能较低 |
| ✅ 类型提示支持 | ⚠️ 支持但不强制 |

**权衡**：
- ❌ 学习曲线略陡（异步编程）
- ❌ 社区比 Flask 小（但增长快）
- ❌ 部分库不支持异步（可用 `run_in_executor` 包装）

**后果**：
- 团队需学习异步编程模式
- 可直接使用异步数据库驱动（asyncpg）
- API 文档自动生成，减少维护成本

---

### ADR-002: PostgreSQL vs MongoDB？

**状态**：已接受  
**决策日期**：2024-11-20

**决策**：
使用 **PostgreSQL 15**

**理由**：
1. **需要事务**：用户注册涉及多表操作（users + sessions）
2. **数据结构相对固定**：用户、认证等数据模型稳定
3. **团队经验**：团队熟悉 SQL，有 DBA 支持
4. **工具成熟**：Alembic 迁移、pgAdmin 管理工具

**权衡**：
- MongoDB 更适合动态 Schema，但我们不需要
- PostgreSQL 扩展性略逊 MongoDB，但足够应对当前规模（< 1M 用户）

---

### ADR-003: JWT 还是 Session？

**状态**：已接受  
**决策日期**：2024-11-20

**决策**：
使用 **JWT（RS256）+ Refresh Token**

**理由**：
- Stateless：无需服务端存储会话
- 可扩展：支持水平扩展（多服务器）
- 微服务友好：Token 可跨服务验证

**实现细节**：
```python
# Access Token（短期）
{
  "sub": "user_id",
  "exp": 1700000000,  # 15 分钟后过期
  "type": "access"
}

# Refresh Token（长期）
{
  "sub": "user_id",
  "exp": 1700604800,  # 7 天后过期
  "type": "refresh",
  "jti": "unique_token_id"  # 用于撤销
}
```

**安全措施**：
- Refresh Token 存储在 Redis（可撤销）
- 使用 RS256（非对称加密，私钥签名，公钥验证）
- Access Token 不可撤销（短期失效可接受）

---

### ADR-004: Next.js App Router vs Pages Router？

**状态**：已接受  
**决策日期**：2024-11-20

**决策**：
使用 **App Router**（Next.js 13+）

**理由**：
- React Server Components（RSC）
- 更好的布局支持（嵌套布局）
- 原生支持 Server Actions
- 更细粒度的数据获取

**权衡**：
- 学习曲线陡峭（新概念）
- 部分第三方库不兼容（逐步改善）

---

## 🗄️ 数据库设计

### 3.1 实体关系图（ERD）

```mermaid
erDiagram
    USER ||--o{ SESSION : has
    USER ||--o{ API_KEY : owns
    USER ||--o{ AUDIT_LOG : generates
    USER }o--|| ROLE : has
    ROLE ||--o{ PERMISSION : contains
    
    USER {
        uuid id PK
        string email UK
        boolean email_verified
        string username UK
        string password_hash
        timestamp created_at
        timestamp updated_at
        timestamp last_login_at
        timestamp deleted_at
    }
    
    SESSION {
        uuid id PK
        uuid user_id FK
        string refresh_token_jti UK
        string ip_address
        string user_agent
        timestamp expires_at
        timestamp created_at
    }
    
    API_KEY {
        uuid id PK
        uuid user_id FK
        string key_hash UK
        string name
        timestamp last_used_at
        timestamp expires_at
        timestamp created_at
    }
    
    ROLE {
        int id PK
        string name UK
        string description
    }
    
    PERMISSION {
        int id PK
        int role_id FK
        string resource
        string action
    }
    
    AUDIT_LOG {
        uuid id PK
        uuid user_id FK
        string action
        json metadata
        timestamp created_at
    }
```

### 3.2 数据表详细设计

#### 表：users

```sql
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) NOT NULL,
    email_verified BOOLEAN NOT NULL DEFAULT FALSE,
    username VARCHAR(20) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    
    -- 审计字段
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    last_login_at TIMESTAMP,
    deleted_at TIMESTAMP,  -- 软删除
    
    -- 唯一约束（不区分大小写）
    CONSTRAINT users_email_unique UNIQUE (LOWER(email)),
    CONSTRAINT users_username_unique UNIQUE (LOWER(username))
);

-- 索引
CREATE INDEX idx_users_email_lower ON users (LOWER(email));
CREATE INDEX idx_users_username_lower ON users (LOWER(username));
CREATE INDEX idx_users_created_at ON users (created_at DESC);
CREATE INDEX idx_users_deleted_at ON users (deleted_at) WHERE deleted_at IS NULL;

-- 自动更新 updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_users_updated_at 
    BEFORE UPDATE ON users 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();
```

#### 表：sessions

```sql
CREATE TABLE sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    refresh_token_jti VARCHAR(255) NOT NULL UNIQUE,
    
    -- 会话信息
    ip_address INET,
    user_agent TEXT,
    
    -- 时间戳
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    
    -- 索引
    CONSTRAINT sessions_refresh_token_jti_unique UNIQUE (refresh_token_jti)
);

CREATE INDEX idx_sessions_user_id ON sessions (user_id);
CREATE INDEX idx_sessions_expires_at ON sessions (expires_at);

-- 自动清理过期会话（定时任务）
CREATE INDEX idx_sessions_expired ON sessions (expires_at) 
    WHERE expires_at < NOW();
```

### 3.3 数据迁移策略

**使用 Alembic 进行版本化迁移**：

```python
# migrations/versions/001_create_users_table.py

"""create users table

Revision ID: 001
Revises: 
Create Date: 2024-11-22

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = '001'
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    # 创建 users 表
    op.create_table(
        'users',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('email', sa.String(255), nullable=False),
        sa.Column('email_verified', sa.Boolean(), nullable=False, server_default='false'),
        sa.Column('username', sa.String(20), nullable=False),
        sa.Column('password_hash', sa.String(255), nullable=False),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(), nullable=False, server_default=sa.func.now()),
        sa.Column('last_login_at', sa.DateTime()),
        sa.Column('deleted_at', sa.DateTime()),
    )
    
    # 创建索引
    op.create_index(
        'idx_users_email_lower',
        'users',
        [sa.text('LOWER(email)')],
        unique=True
    )
    op.create_index(
        'idx_users_username_lower',
        'users',
        [sa.text('LOWER(username)')],
        unique=True
    )

def downgrade():
    op.drop_index('idx_users_email_lower', table_name='users')
    op.drop_index('idx_users_username_lower', table_name='users')
    op.drop_table('users')
```

---

## 🌐 API 设计

### 4.1 API 设计原则

1. **RESTful 风格**：
   - 使用标准 HTTP 方法（GET, POST, PUT, PATCH, DELETE）
   - 资源名词化（`/users` 而非 `/getUsers`）

2. **版本控制**：
   - URL 中体现版本：`/api/v1/...`
   - 向后兼容至少 1 个大版本

3. **统一响应格式**：
   ```json
   // 成功响应
   {
     "data": {...},
     "meta": {
       "timestamp": "2024-11-22T10:30:00Z",
       "request_id": "req_abc123"
     }
   }
   
   // 错误响应
   {
     "error": "ERROR_CODE",
     "message": "Human-readable message",
     "details": {...},
     "meta": {
       "timestamp": "2024-11-22T10:30:00Z",
       "request_id": "req_abc123"
     }
   }
   ```

4. **分页**：
   - 使用 Cursor-Based Pagination（推荐）或 Offset-Based
   - 格式：`?cursor=abc123&limit=20`

5. **过滤与排序**：
   - 过滤：`?status=active&role=admin`
   - 排序：`?sort=created_at:desc`

6. **幂等性**：
   - POST：非幂等（创建新资源）
   - PUT/PATCH/DELETE：幂等

### 4.2 端点清单

| 端点 | 方法 | 认证 | 描述 |
|------|------|------|------|
| `/api/v1/auth/register` | POST | ❌ | 用户注册 |
| `/api/v1/auth/login` | POST | ❌ | 用户登录 |
| `/api/v1/auth/refresh` | POST | ❌ | 刷新 Token |
| `/api/v1/auth/logout` | POST | ✅ | 登出（撤销 Token）|
| `/api/v1/users/me` | GET | ✅ | 获取当前用户信息 |
| `/api/v1/users/me` | PATCH | ✅ | 更新当前用户信息 |
| `/api/v1/users/:id` | GET | ✅ | 获取用户详情 |
| `/health` | GET | ❌ | 健康检查 |

### 4.3 OpenAPI 规范生成

FastAPI 自动生成 OpenAPI 文档，访问 `/docs` 查看 Swagger UI。

**自定义文档元数据**：
```python
# src/main.py

from fastapi import FastAPI

app = FastAPI(
    title="My API",
    description="API for user management and authentication",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
    openapi_tags=[
        {
            "name": "auth",
            "description": "认证相关操作（注册、登录、登出）"
        },
        {
            "name": "users",
            "description": "用户管理操作"
        }
    ]
)
```

---

## 🔒 安全架构

### 5.1 认证流程

```mermaid
sequenceDiagram
    participant Client
    participant API
    participant DB
    participant Redis
    
    Client->>API: POST /auth/login
    API->>DB: 查询用户
    DB-->>API: 用户信息
    API->>API: 验证密码（bcrypt）
    API->>API: 生成 Access Token (15min)
    API->>API: 生成 Refresh Token (7d)
    API->>Redis: 存储 Refresh Token JTI
    API-->>Client: {access_token, refresh_token}
    
    Note over Client,API: 后续请求携带 Access Token
    
    Client->>API: GET /users/me<br/>Header: Authorization: Bearer {access_token}
    API->>API: 验证 Access Token
    API->>DB: 查询用户数据
    DB-->>API: 用户数据
    API-->>Client: 用户信息
    
    Note over Client,API: Access Token 过期后刷新
    
    Client->>API: POST /auth/refresh<br/>{refresh_token}
    API->>Redis: 验证 Refresh Token 是否被撤销
    Redis-->>API: Token 有效
    API->>API: 生成新 Access Token
    API-->>Client: {access_token}
```

### 5.2 授权模型（RBAC）

```python
# src/models/role.py

class Role(Base):
    __tablename__ = "roles"
    
    id = Column(Integer, primary_key=True)
    name = Column(String(50), unique=True, nullable=False)
    permissions = relationship("Permission", back_populates="role")

class Permission(Base):
    __tablename__ = "permissions"
    
    id = Column(Integer, primary_key=True)
    role_id = Column(Integer, ForeignKey("roles.id"))
    resource = Column(String(50), nullable=False)  # 例如："users"
    action = Column(String(50), nullable=False)    # 例如："read", "write"
    
    role = relationship("Role", back_populates="permissions")
```

**权限检查装饰器**：
```python
# src/api/dependencies.py

from fastapi import Depends, HTTPException, status
from src.core.security import get_current_user

def require_permission(resource: str, action: str):
    async def permission_checker(
        current_user: User = Depends(get_current_user)
    ):
        has_permission = await check_permission(
            user=current_user,
            resource=resource,
            action=action
        )
        if not has_permission:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Insufficient permissions"
            )
        return current_user
    return permission_checker

# 使用
@app.get("/api/v1/users/{user_id}")
async def get_user(
    user_id: str,
    current_user: User = Depends(require_permission("users", "read"))
):
    ...
```

### 5.3 安全检查清单

- [ ] **传输加密**：强制 HTTPS（TLS 1.3）
- [ ] **存储加密**：密码用 bcrypt（cost=12），敏感数据 AES-256
- [ ] **输入验证**：Pydantic 模型 + 自定义验证器
- [ ] **SQL 注入**：使用 ORM 参数化查询
- [ ] **XSS**：FastAPI 自动转义输出
- [ ] **CSRF**：Stateless API 不需要（如有表单则需 CSRF Token）
- [ ] **频率限制**：Redis + Middleware
- [ ] **CORS**：配置允许的域名白名单
- [ ] **日志脱敏**：自动移除密码、Token
- [ ] **依赖扫描**：使用 `safety` 和 `pip-audit`

---

## 📊 可观测性设计

### 6.1 日志

**结构化日志（JSON 格式）**：
```python
# src/core/logging.py

import structlog

structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
        structlog.processors.JSONRenderer()
    ],
    context_class=dict,
    logger_factory=structlog.stdlib.LoggerFactory(),
    cache_logger_on_first_use=True,
)

logger = structlog.get_logger()

# 使用
logger.info(
    "user_login",
    user_id=user.id,
    email=mask_email(user.email),
    ip_address=request.client.host
)
```

### 6.2 指标（Metrics）

**使用 Prometheus 格式暴露指标**：
```python
# src/api/metrics.py

from prometheus_client import Counter, Histogram, generate_latest

# 定义指标
http_requests_total = Counter(
    'http_requests_total',
    'Total HTTP requests',
    ['method', 'endpoint', 'status']
)

http_request_duration_seconds = Histogram(
    'http_request_duration_seconds',
    'HTTP request duration'
)

# Middleware 记录指标
@app.middleware("http")
async def metrics_middleware(request: Request, call_next):
    start_time = time.time()
    response = await call_next(request)
    duration = time.time() - start_time
    
    http_requests_total.labels(
        method=request.method,
        endpoint=request.url.path,
        status=response.status_code
    ).inc()
    
    http_request_duration_seconds.observe(duration)
    
    return response

# 暴露指标端点
@app.get("/metrics")
async def metrics():
    return Response(
        generate_latest(),
        media_type="text/plain"
    )
```

### 6.3 追踪（Tracing）

**使用 OpenTelemetry**：
```python
# src/core/tracing.py

from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.jaeger import JaegerExporter

# 配置
trace.set_tracer_provider(TracerProvider())
jaeger_exporter = JaegerExporter(
    agent_host_name="localhost",
    agent_port=6831,
)
trace.get_tracer_provider().add_span_processor(
    BatchSpanProcessor(jaeger_exporter)
)

tracer = trace.get_tracer(__name__)

# 使用
with tracer.start_as_current_span("process_registration"):
    # 业务逻辑
    pass
```

---

## 🚀 部署配置

### 7.1 Docker 配置

```dockerfile
# Dockerfile

FROM python:3.11-slim

WORKDIR /app

# 安装依赖
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# 复制代码
COPY src/ ./src/
COPY migrations/ ./migrations/

# 暴露端口
EXPOSE 8000

# 健康检查
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
    CMD curl -f http://localhost:8000/health || exit 1

# 启动命令
CMD ["uvicorn", "src.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

### 7.2 Docker Compose（本地开发）

```yaml
# docker-compose.yml

version: '3.9'

services:
  api:
    build: .
    ports:
      - "8000:8000"
    environment:
      - DATABASE_URL=postgresql://user:pass@postgres:5432/mydb
      - REDIS_URL=redis://redis:6379
    depends_on:
      - postgres
      - redis
    volumes:
      - ./src:/app/src  # 热重载

  postgres:
    image: postgres:15-alpine
    environment:
      POSTGRES_USER: user
      POSTGRES_PASSWORD: pass
      POSTGRES_DB: mydb
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"

volumes:
  postgres_data:
```

---

## 📝 变更日志

| 日期 | 版本 | 变更内容 |
|------|------|---------|
| 2024-11-22 | v1.0.0 | 初始架构设计 |

---

**维护说明**：
1. 所有架构变更必须更新此文档
2. ADR 记录所有重大技术决策
3. 数据库 Schema 变更需对应迁移脚本
